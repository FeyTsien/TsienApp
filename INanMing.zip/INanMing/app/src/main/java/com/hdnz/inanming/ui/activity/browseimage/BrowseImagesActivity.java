package com.hdnz.inanming.ui.activity.browseimage;

import android.content.Intent;
import android.support.v4.view.ViewPager;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.hdnz.inanming.R;
import com.tsienlibrary.ui.activity.BaseActivity;

import java.util.ArrayList;
import java.util.List;

import butterknife.BindView;
import uk.co.senab.photoview.PhotoView;

public class BrowseImagesActivity extends BaseActivity {
    @BindView(R.id.tv_title)
    TextView tvTitle;
    @BindView(R.id.vp_img)
    PhotoViewPager vpImg;
    @BindView(R.id.ll_dot)
    LinearLayout llDot;
    private ArrayList<String> imgUrls;
    private List<String> mTitls;
    private List<View> mPhotoViews;
    private int mPos;
    private List<ImageView> dots = new ArrayList<>();

    @Override
    protected int getLayoutId() {
        return R.layout.activity_browse_images;
    }

    @Override
    protected void initData() {
        /**
         * 获取数据
         */
        Intent intent = getIntent();
        imgUrls = intent.getStringArrayListExtra("imgUrls");
        mPos = intent.getIntExtra("pos", 0);
        mTitls = new ArrayList<>();
        mPhotoViews = new ArrayList<>();
        for (int i = 0; i < imgUrls.size(); i++) {
            int j = i + 1;
            View view = LayoutInflater.from(this).inflate(R.layout.browser_photoview_layout, null);
            PhotoView photoView = (PhotoView) view.findViewById(R.id.pv_photo);
            photoView.setAdjustViewBounds(true);
            photoView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    finish();
                }
            });

            mTitls.add(j + "");
            //网络加载图片
            Glide.with(this).load(imgUrls.get(i)).into(photoView);

            ImageView imageView = new ImageView(this);
            imageView.setBackground(getResources().getDrawable(R.drawable.dot_normal));
            LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(-2, -2);
            layoutParams.setMargins(5,5,5,5);
            imageView.setLayoutParams(layoutParams);
            llDot.addView(imageView, i);
            dots.add(imageView);
            mPhotoViews.add(view);
        }
    }

    /**
     * 初始化
     */
    @Override
    protected void initView() {
        BrowseAdapter browseAdapter = new BrowseAdapter(this, mPhotoViews, mTitls);
        vpImg.setAdapter(browseAdapter);
        vpImg.setCurrentItem(mPos);
        tvTitle.setText(mPos + 1 + "/" + imgUrls.size());
        dots.get(mPos).setBackground(getResources().getDrawable(R.drawable.dot_selected));
        vpImg.addOnPageChangeListener(new ViewPager.OnPageChangeListener() {
            @Override
            public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {

            }

            @Override
            public void onPageSelected(int position) {
                int pos = position + 1;
                tvTitle.setText(pos + "/" + imgUrls.size());
                for (int i = 0; i < dots.size(); i++) {
                    if (i == position) {
                        dots.get(position).setBackground(getResources().getDrawable(R.drawable.dot_selected));
                    }else {
                        dots.get(i).setBackground(getResources().getDrawable(R.drawable.dot_normal));
                    }
                }

            }

            @Override
            public void onPageScrollStateChanged(int state) {

            }
        });
    }

    @Override
    public void onBackPressed() {
        finish();
    }
}
