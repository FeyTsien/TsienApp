package com.hdnz.inanming.utils;

import com.blankj.utilcode.util.BarUtils;
import com.hdnz.inanming.app.AppData;

/**
 * Created by Administrator on 2017/4/10.
 */

public class UrlUtils {

    //TODO:============================  H5 URL  ===================================================
    //首页主连接
    public static final String H5_HOME_BASE_URL = "http://192.168.3.233:8007/";//http://192.168.3.233:8007/     http://47.92.165.143:8007/
    //电商首页连接
    public static final String H5_SHOP_BASE_URL = "http://192.168.3.234:8080/";//http://192.168.3.234:8080/    http://47.92.165.143:8010/

    //首页子连接(参数有：token、statusHeight)
    public static final String H5_HOME = "?token=" + AppData.getToken() + "&statusHeight=" + BarUtils.getStatusBarHeight();
    //我的订单(参数有：token、userId、statusHeight)
    public static final String H5_SHOP_ORDER_LIST = "orderList?token=" + AppData.getToken() + "&userId=" + AppData.getUserId() + "&statusHeight=" + BarUtils.getStatusBarHeight();

    //TODO:==========================  服务器 BASE URL  ============================================
    //用户中心 BaseUrl
    public static final String BASEURL = "http://47.92.165.143:8002/";//http://192.168.3.128:8005/   http://47.92.165.143:8005/
//    //社区 BaseUrl
//    public static final String BASEURL_COMMUNITY = "http://47.92.165.143:8002/";//http://192.168.3.49:8004/   http://47.92.165.143:8002/
//    //电商 BaseUrl
//    public static final String BASEURL_STORE = "http://47.92.219.176:8009/AiNanMingAppService/";
//    //文件服务器 BaseUrl
//    public static final String BASEURL_FILE_CENTER = "http://47.92.165.143:8008/FileCenter/";

    //TODO:============================  接口名  ===================================================

    public static final String TEST = "test";
    //============用户中心==================
    //获取验证码
    public static final String GET_SMS_CODE = "hdnz-ucenter/api/v1/user_account/selectSms";
    //注册
    public static final String LOG_UP = "hdnz-ucenter/api/v1/user_account/register";
    //登录
    public static final String LOGIN = "hdnz-ucenter/api/v1/user_account/login";
    //忘记密码
    public static final String FORGET_PWD = "hdnz-ucenter/api/v1/user_account/updatepwd";
    //退出
    public static final String LOG_OUT = "hdnz-ucenter/api/v1/user_account/sign";
    //修改手机号
    public static final String UPDATE_PHONE_NUMBER = "hdnz-ucenter/api/v1/user_account/updatephonenum";
    //修改用户信息
    public static final String UPDATE_USER_INFO = "hdnz-ucenter/api/v1/user_account/updateUserAccount";

    //============图片上传======================
    //图片上传-多
    public static final String UPLOAD_IMAGES = "FileCenter/api/file/batchupload";
    //图片上传-单
    public static final String UPLOAD_IMAGE = "FileCenter/api/file/upload";

    //============社区======================
    //新闻头条
    public static final String HEAD_LINE = "community/api/community-posts/verify/pageSearch";
    //文章收藏列表
    public static final String COLLECT_ARTICLES = "community/api/community-collect/verify/pagingQueryCollect";
    //店铺收藏列表
    public static final String COLLECT_SHOPS = "community/api/community-collect/verify/pagingQueryCollect";


    //============电商======================
    //商铺列表
    public static final String STORE_LIST = "store/storelist";


}
