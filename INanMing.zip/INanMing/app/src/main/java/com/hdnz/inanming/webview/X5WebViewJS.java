package com.hdnz.inanming.webview;

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.widget.Toast;

import com.blankj.utilcode.util.ActivityUtils;
import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.hdnz.inanming.ui.popup.MobSharePopup;
import com.hdnz.inanming.ui.activity.login.LoginActivity;

import org.json.JSONArray;
import org.json.JSONObject;

/**
 * 注册方法，提供给js调用
 */
public class X5WebViewJS {
    private Context mContext;
    private X5WebView mWebView;

    public X5WebViewJS(Context context, X5WebView webView) {
        mContext = context;
        mWebView = webView;
    }

    /**
     * TODO:打开新连接，跳转到WebViewActivity
     */
    @JavascriptInterface
    public void goToUrl(String url) {
        //跳转到WebViewActivity
        WebViewActivity.goToWebView(mContext, url);
//        WebViewActivity.goToWebView(mContext,"https://www.baidu.com");
    }

    /**
     * TODO:关闭WebViewActivity
     */
    @JavascriptInterface
    public void finish() {
        ((Activity) mContext).finish();
    }

    /**
     * TODO:前往登录页
     */
    @JavascriptInterface
    public void goToLogin() {
        ActivityUtils.startActivity(LoginActivity.class);
    }

    /**
     * TODO:前往分享
     */
    @JavascriptInterface
    public void shareAction(String share) {
        (MobSharePopup.getInstance(mContext, share)).showPopupWindow();
    }


    //====================================   其他（可忽略）   =============================================

    @JavascriptInterface //js调用Android方法
    public void onX5ButtonClicked() {
        //X5全屏模式
        enableX5FullscreenFunc();
    }

    @JavascriptInterface
    public void onCustomButtonClicked() {
        //恢复webkit初始模式
        disableX5FullscreenFunc();
    }

    @JavascriptInterface
    public void onLiteWndButtonClicked() {
        //开启小窗模式
        enableLiteWndFunc();
    }

    @JavascriptInterface
    public void onPageVideoClicked() {
        //页面内全屏播放模式
        enablePageVideoFunc();
    }


    /**
     * 开启X5全屏播放模式
     */
    private void enableX5FullscreenFunc() {
        if (mWebView.getX5WebViewExtension() != null) {
            Toast.makeText(mContext, "开启X5全屏播放模式", Toast.LENGTH_LONG).show();
            Bundle data = new Bundle();
            data.putBoolean("standardFullScreen", false);// true表示标准全屏，false表示X5全屏；不设置默认false，
            data.putBoolean("supportLiteWnd", false);// false：关闭小窗；true：开启小窗；不设置默认true，
            data.putInt("DefaultVideoScreen", 2);// 1：以页面内开始播放，2：以全屏开始播放；不设置默认：1
            mWebView.getX5WebViewExtension().invokeMiscMethod("setVideoParams",
                    data);
        }
    }

    /**
     * 恢复webkit初始状态
     */
    private void disableX5FullscreenFunc() {
        if (mWebView.getX5WebViewExtension() != null) {
            Toast.makeText(mContext, "恢复webkit初始状态", Toast.LENGTH_LONG).show();
            Bundle data = new Bundle();

            data.putBoolean("standardFullScreen", true);// true表示标准全屏，会调起onShowCustomView()，false表示X5全屏；不设置默认false，

            data.putBoolean("supportLiteWnd", false);// false：关闭小窗；true：开启小窗；不设置默认true，

            data.putInt("DefaultVideoScreen", 2);// 1：以页面内开始播放，2：以全屏开始播放；不设置默认：1

            mWebView.getX5WebViewExtension().invokeMiscMethod("setVideoParams",
                    data);
        }
    }

    /**
     * 开启小窗模式
     */
    private void enableLiteWndFunc() {
        if (mWebView.getX5WebViewExtension() != null) {
            Toast.makeText(mContext, "开启小窗模式", Toast.LENGTH_LONG).show();
            Bundle data = new Bundle();

            data.putBoolean("standardFullScreen", false);// true表示标准全屏，会调起onShowCustomView()，false表示X5全屏；不设置默认false，

            data.putBoolean("supportLiteWnd", true);// false：关闭小窗；true：开启小窗；不设置默认true，

            data.putInt("DefaultVideoScreen", 2);// 1：以页面内开始播放，2：以全屏开始播放；不设置默认：1

            mWebView.getX5WebViewExtension().invokeMiscMethod("setVideoParams",
                    data);
        }
    }

    /**
     * 页面内全屏播放模式
     */
    private void enablePageVideoFunc() {
        if (mWebView.getX5WebViewExtension() != null) {
            Toast.makeText(mContext, "页面内全屏播放模式", Toast.LENGTH_LONG).show();
            Bundle data = new Bundle();

            data.putBoolean("standardFullScreen", false);// true表示标准全屏，会调起onShowCustomView()，false表示X5全屏；不设置默认false，

            data.putBoolean("supportLiteWnd", false);// false：关闭小窗；true：开启小窗；不设置默认true，

            data.putInt("DefaultVideoScreen", 1);// 1：以页面内开始播放，2：以全屏开始播放；不设置默认：1

            mWebView.getX5WebViewExtension().invokeMiscMethod("setVideoParams",
                    data);
        }
    }

}
