package com.hdnz.inanming.ui.activity.browseimage;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.view.PagerAdapter;
import android.view.View;
import android.view.ViewGroup;

import java.util.List;

/**
 * Copyright (C), 2017-2018, 华电南自（贵州）科技有限公司
 * FileName:    BrowseAdapter.java
 * Author:      肖昕
 * Email:       xiaox@huadiannanzi.com
 * Date:        2018-11-13 15:44
 * Description:
 * Version:     V1.0.0
 * History:     历史信息
 */
public class BrowseAdapter extends PagerAdapter {
    private Context mContext;
    private List<View> photoViews;
    private List<String> titles;

    public BrowseAdapter(Context mContext, List<View> photoViews, List<String> titles) {
        this.mContext = mContext;
        this.photoViews = photoViews;
        this.titles = titles;
    }

    @Override
    public int getCount() {
        return photoViews.size();
    }

    @Override
    public boolean isViewFromObject(@NonNull View view, @NonNull Object object) {
        return view == object;
    }

    @NonNull
    @Override
    public Object instantiateItem(@NonNull ViewGroup container, int position) {
        container.addView(photoViews.get(position));
        return photoViews.get(position);
    }

    @Override
    public void destroyItem(@NonNull ViewGroup container, int position, @NonNull Object object) {
        container.removeView(photoViews.get(position));
    }

    @Override
    public int getItemPosition(Object object) {
        return POSITION_NONE;
    }
}
