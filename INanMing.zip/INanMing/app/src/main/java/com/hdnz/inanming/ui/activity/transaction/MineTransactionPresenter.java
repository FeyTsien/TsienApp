package com.hdnz.inanming.ui.activity.transaction;

import com.hdnz.inanming.mvp.model.HttpManager;
import com.tsienlibrary.mvp.base.BasePresenterImpl;
import com.google.gson.Gson;
import com.hdnz.inanming.bean.ProgressDetailBean;
import com.hdnz.inanming.bean.TransactionDetail2Bean;
import com.hdnz.inanming.bean.TransactionDetailBean;

import io.reactivex.Observer;
import io.reactivex.disposables.Disposable;

/**
 * Copyright (C), 2017-2018, 华电南自（贵州）科技有限公司
 * FileName:    TransactionPresenter.java
 * Author:      肖昕
 * Email:       xiaox@huadiannanzi.com
 * Date:        2018-11-16 18:56
 * Description: 我的办理activity业务处理类
 * Version:     V1.0.0
 * History:     历史信息
 */
public class MineTransactionPresenter extends BasePresenterImpl<MineTransactionContract.View> implements MineTransactionContract.Presenter {

    @Override
    public void getTabTitles(String url, String josn) {

    }

    @Override
    public void seeDetail(String url, String josn, String type) {
        HttpManager.getHttpManager().getMethod(url, new Observer<String>() {
            @Override
            public void onSubscribe(Disposable d) {

            }

            @Override
            public void onNext(String json) {
                Gson gson = new Gson();
                if ("1".equals(type)) {
                    TransactionDetailBean transactionDetailBean = gson.fromJson(json, TransactionDetailBean.class);
                    if (null != mView) {
                        mView.requestSuccess(transactionDetailBean);
                    }
                }else {
                    TransactionDetail2Bean transactionDetail2Bean = gson.fromJson(json, TransactionDetail2Bean.class);
                    if (null != mView) {
                        mView.requestSuccess(transactionDetail2Bean);
                    }
                }
            }

            @Override
            public void onError(Throwable e) {
                if (null != mView) {
                    mView.requestFail("error");
                }
            }

            @Override
            public void onComplete() {

            }
        });
    }

    @Override
    public void seeCheckProgressDetail(String url, String josn) {
        HttpManager.getHttpManager().getMethod(url, new Observer<String>() {
            @Override
            public void onSubscribe(Disposable d) {

            }

            @Override
            public void onNext(String json) {
                Gson gson = new Gson();
                ProgressDetailBean progressDetailBean = gson.fromJson(json, ProgressDetailBean.class);
                if (null != mView) {
                    mView.requestSuccess(progressDetailBean);
                }
            }

            @Override
            public void onError(Throwable e) {
                if (null != mView) {
                    mView.requestFail("error");
                }
            }

            @Override
            public void onComplete() {

            }
        });
    }
}
