package com.hdnz.inanming.ui.activity;

import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.support.annotation.Nullable;
import android.widget.ImageView;

import com.blankj.utilcode.util.ActivityUtils;
import com.blankj.utilcode.util.LogUtils;
import com.hdnz.inanming.R;
import com.hdnz.inanming.app.AppData;
import com.hdnz.inanming.ui.activity.login.LoginActivity;
import com.hdnz.inanming.ui.activity.main.MainActivity;
import com.tsienlibrary.ui.activity.BaseActivity;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.Unbinder;


public class SplashActivity extends Activity {

    private boolean isShowLog;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        initData();
        initView();
    }

    protected void initData() {

        isShowLog = true;

        LogUtils.Config config = LogUtils.getConfig();
        //logSwitch为false关闭日志
        config.setLogSwitch(isShowLog);
    }

    protected void initView() {

//        new Handler().postDelayed(new Runnable() {
//            @Override
//            public void run() {
                start();
//            }
//        }, 0);
    }

    private void start() {
        // 如果是第一次启动，则先进入功能引导页
//        if (AppData.getFirstOpen()==1) {
//            CommonUtils.startActivity(this, WelcomeGuideActivity.class);
//            finish();
//        }else {
        if (AppData.isLogined()) {
            ActivityUtils.startActivity(this, MainActivity.class);
//            ActivityUtils.startActivity(this, MainActivity1.class);
//            ActivityUtils.startActivity(this, MainActivity2.class);
//        ActivityUtils.startActivity(this, DownloadTestActivity.class);
        } else {
            ActivityUtils.startActivity(this, MainActivity.class);
//            ActivityUtils.startActivity(this, LoginActivity.class);
        }
        finish();
    }


    @Override
    protected void onDestroy() {
        super.onDestroy();
    }


}
