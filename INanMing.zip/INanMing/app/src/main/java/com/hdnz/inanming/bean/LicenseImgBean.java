package com.hdnz.inanming.bean;

import java.util.List;

/**
 * Copyright (C), 2017-2018, 华电南自（贵州）科技有限公司
 * FileName:    LicenseImgBean.java
 * Author:      肖昕
 * Email:       xiaox@huadiannanzi.com
 * Date:        2018-11-12 15:08
 * Description:
 * Version:     V1.0.0
 * History:     历史信息
 */
public class LicenseImgBean {

    /**
     * data : ["http://192.168.1.35:8722/img/01.png","http://192.168.1.35:8722/img/11.png","http://192.168.1.35:8722/img/21.png","http://192.168.1.35:8722/img/31.png"]
     * code : 200
     * message : success
     * status : true
     */

    private int code;
    private String message;
    private boolean status;
    private List<String> data;

    public int getCode() {
        return code;
    }

    public void setCode(int code) {
        this.code = code;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public boolean isStatus() {
        return status;
    }

    public void setStatus(boolean status) {
        this.status = status;
    }

    public List<String> getData() {
        return data;
    }

    public void setData(List<String> data) {
        this.data = data;
    }
}
