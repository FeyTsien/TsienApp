package com.hdnz.inanming.bean;

import java.util.List;

/**
 * Copyright (C), 2017-2018, 华电南自（贵州）科技有限公司
 * FileName:    BookBean.java
 * Author:      肖昕
 * Email:       xiaox@huadiannanzi.com
 * Date:        2018-11-27 10:26
 * Description:
 * Version:     V1.0.0
 * History:     历史信息
 */
public class BookBean {

    /**
     * data : [{"headUrl":"http://192.168.1.35:8722/img/1.png","manageUint":"南民区税务局-花果园","proveType":"贵州省老年优待证","statusText":"取消预约","status":true,"takeNum":"未取号","bookTime":"2018-11-27 10:25:44","lineUpNum":"0 人"},{"headUrl":"http://192.168.1.35:8722/img/1.png","manageUint":"南民区税务局-花果园","proveType":"贵州省老年优待证","statusText":"已失效","status":false,"takeNum":"未取号","bookTime":"2018-11-27 10:25:44","lineUpNum":"1 人"},{"headUrl":"http://192.168.1.35:8722/img/1.png","manageUint":"南民区税务局-花果园","proveType":"贵州省老年优待证","statusText":"取消预约","status":true,"takeNum":"未取号","bookTime":"2018-11-27 10:25:44","lineUpNum":"2 人"},{"headUrl":"http://192.168.1.35:8722/img/1.png","manageUint":"南民区税务局-花果园","proveType":"贵州省老年优待证","statusText":"已失效","status":false,"takeNum":"未取号","bookTime":"2018-11-27 10:25:44","lineUpNum":"3 人"},{"headUrl":"http://192.168.1.35:8722/img/1.png","manageUint":"南民区税务局-花果园","proveType":"贵州省老年优待证","statusText":"取消预约","status":true,"takeNum":"未取号","bookTime":"2018-11-27 10:25:44","lineUpNum":"4 人"},{"headUrl":"http://192.168.1.35:8722/img/1.png","manageUint":"南民区税务局-花果园","proveType":"贵州省老年优待证","statusText":"已失效","status":false,"takeNum":"未取号","bookTime":"2018-11-27 10:25:44","lineUpNum":"5 人"},{"headUrl":"http://192.168.1.35:8722/img/1.png","manageUint":"南民区税务局-花果园","proveType":"贵州省老年优待证","statusText":"取消预约","status":true,"takeNum":"未取号","bookTime":"2018-11-27 10:25:44","lineUpNum":"6 人"},{"headUrl":"http://192.168.1.35:8722/img/1.png","manageUint":"南民区税务局-花果园","proveType":"贵州省老年优待证","statusText":"已失效","status":false,"takeNum":"未取号","bookTime":"2018-11-27 10:25:44","lineUpNum":"7 人"},{"headUrl":"http://192.168.1.35:8722/img/1.png","manageUint":"南民区税务局-花果园","proveType":"贵州省老年优待证","statusText":"取消预约","status":true,"takeNum":"未取号","bookTime":"2018-11-27 10:25:44","lineUpNum":"8 人"},{"headUrl":"http://192.168.1.35:8722/img/1.png","manageUint":"南民区税务局-花果园","proveType":"贵州省老年优待证","statusText":"已失效","status":false,"takeNum":"未取号","bookTime":"2018-11-27 10:25:44","lineUpNum":"9 人"}]
     * code : 200
     * message : success
     * status : true
     */

    private int code;
    private String message;
    private boolean status;
    private List<DataBean> data;

    public int getCode() {
        return code;
    }

    public void setCode(int code) {
        this.code = code;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public boolean isStatus() {
        return status;
    }

    public void setStatus(boolean status) {
        this.status = status;
    }

    public List<DataBean> getData() {
        return data;
    }

    public void setData(List<DataBean> data) {
        this.data = data;
    }

    public static class DataBean {
        /**
         * headUrl : http://192.168.1.35:8722/img/1.png
         * manageUint : 南民区税务局-花果园
         * proveType : 贵州省老年优待证
         * statusText : 取消预约
         * status : true
         * takeNum : 未取号
         * bookTime : 2018-11-27 10:25:44
         * lineUpNum : 0 人
         */

        private String headUrl;
        private String manageUint;
        private String proveType;
        private String statusText;
        private boolean status;
        private String takeNum;
        private String bookTime;
        private String lineUpNum;

        public String getHeadUrl() {
            return headUrl;
        }

        public void setHeadUrl(String headUrl) {
            this.headUrl = headUrl;
        }

        public String getManageUint() {
            return manageUint;
        }

        public void setManageUint(String manageUint) {
            this.manageUint = manageUint;
        }

        public String getProveType() {
            return proveType;
        }

        public void setProveType(String proveType) {
            this.proveType = proveType;
        }

        public String getStatusText() {
            return statusText;
        }

        public void setStatusText(String statusText) {
            this.statusText = statusText;
        }

        public boolean isStatus() {
            return status;
        }

        public void setStatus(boolean status) {
            this.status = status;
        }

        public String getTakeNum() {
            return takeNum;
        }

        public void setTakeNum(String takeNum) {
            this.takeNum = takeNum;
        }

        public String getBookTime() {
            return bookTime;
        }

        public void setBookTime(String bookTime) {
            this.bookTime = bookTime;
        }

        public String getLineUpNum() {
            return lineUpNum;
        }

        public void setLineUpNum(String lineUpNum) {
            this.lineUpNum = lineUpNum;
        }
    }
}
