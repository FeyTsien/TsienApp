package com.hdnz.inanming.ui.activity.me.information;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v4.content.ContextCompat;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import com.blankj.utilcode.util.ActivityUtils;
import com.blankj.utilcode.util.ToastUtils;
import com.hdnz.inanming.R;
import com.hdnz.inanming.bean.AddressBean;
import com.hdnz.inanming.bean.BaseBean;
import com.hdnz.inanming.mvp.contract.MVPContract;
import com.hdnz.inanming.mvp.presenter.MVPPresenter;
import com.hdnz.inanming.mvp.view.MVPActivity;
import com.hdnz.inanming.ui.activity.me.information.address.MineAddressActivity;
import com.hdnz.inanming.ui.adapter.RecyclerViewAdapter;
import com.scwang.smartrefresh.layout.SmartRefreshLayout;
import com.scwang.smartrefresh.layout.api.RefreshLayout;
import com.scwang.smartrefresh.layout.listener.OnRefreshLoadMoreListener;
import com.yanzhenjie.recyclerview.swipe.SwipeItemClickListener;
import com.yanzhenjie.recyclerview.swipe.SwipeMenu;
import com.yanzhenjie.recyclerview.swipe.SwipeMenuBridge;
import com.yanzhenjie.recyclerview.swipe.SwipeMenuCreator;
import com.yanzhenjie.recyclerview.swipe.SwipeMenuItem;
import com.yanzhenjie.recyclerview.swipe.SwipeMenuItemClickListener;
import com.yanzhenjie.recyclerview.swipe.SwipeMenuRecyclerView;
import com.yanzhenjie.recyclerview.swipe.widget.DefaultItemDecoration;

import java.util.ArrayList;
import java.util.List;

import butterknife.BindView;
import butterknife.OnClick;

/**
 * Copyright (C), 2017-2018, 华电南自（贵州）科技有限公司
 * FileName:    SettingActivity.java
 * Author:      肖昕
 * Email:       xiaox@huadiannanzi.com
 * Date:        2018-11-06 14:09
 * Description: 用户地址列表activity
 * Version:     V1.0.0
 * History:     历史信息
 */
public class AddressListActivity extends MVPActivity<MVPContract.View, MVPPresenter> {

    @BindView(R.id.toolbar)
    Toolbar mToolbar;
    @BindView(R.id.tv_title)
    TextView tvTitle;
    @BindView(R.id.tv_right_menu)
    TextView tvRightMenu;
    @BindView(R.id.rv_list)
    SwipeMenuRecyclerView rvList;
    private List<AddressBean> addressBeanList;
    private RecyclerViewAdapter recyclerViewAdapter;
    private static final String TAG = "AddressListActivity";

    @Override
    protected int getLayoutId() {
        return R.layout.activity_address_list;
    }

    @Override
    protected void initData() {
        addressBeanList = new ArrayList<>();
        for (int i = 0; i < 5; i++) {
            AddressBean addressBean = new AddressBean();
            addressBean.setAddress("贵州省 贵阳市 南明区 悠然居" + i + "栋 " + i + "单元 " + i + "楼 50" + i + "房间");
            addressBean.setName("肖昕" + i);
            addressBean.setPhone("1551929425" + i);
            if (i == 0) {
                addressBean.setCheck(true);
            } else {
                addressBean.setCheck(false);
            }
            addressBeanList.add(addressBean);
        }

    }

    @Override
    protected void initView() {
        //设置title
        setToolBar(mToolbar, tvTitle, getResources().getString(R.string.mine_address));
        tvRightMenu.setVisibility(View.VISIBLE);
        //设置save文本，为“完成”
        tvRightMenu.setText(R.string.add);

        //设置列表
        LinearLayoutManager layoutManager = new LinearLayoutManager(this);
        layoutManager.setOrientation(LinearLayoutManager.VERTICAL);
        rvList.setLayoutManager(layoutManager);
        //rvList.addItemDecoration(new DividerItemDecoration(this, DividerItemDecoration.VERTICAL));
        rvList.addItemDecoration(new DefaultItemDecoration(ContextCompat.getColor(this, R.color.me_divider), 1, 1));

        // 策划删除，默认关闭，需打开，此处bug 需设置false
        rvList.setItemViewSwipeEnabled(false);

        //recyclerview点击item 事件
        rvList.setSwipeItemClickListener(new SwipeItemClickListener() {
            @Override
            public void onItemClick(View itemView, int position) {
                ToastUtils.showShort("跳转编辑： position: " + position);
                Intent intent = new Intent(AddressListActivity.this, MineAddressActivity.class);
                Bundle bundle = new Bundle();
                bundle.putBoolean("edit", true);
                bundle.putBoolean("add", false);
                bundle.putParcelable("address", addressBeanList.get(position));
                intent.putExtras(bundle);
                ActivityUtils.startActivity(intent);
            }
        });

        // 创建侧滑菜单：
        rvList.setSwipeMenuCreator(new SwipeMenuCreator() {
            @Override
            public void onCreateMenu(SwipeMenu swipeLeftMenu, SwipeMenu swipeRightMenu, int viewType) {
                int width = getResources().getDimensionPixelSize(R.dimen.dp_90);
                // 1. MATCH_PARENT 自适应高度，保持和Item一样高;
                // 2. 指定具体的高，比如80;
                // 3. WRAP_CONTENT，自身高度，不推荐;
//                int height =  getResources().getDimensionPixelSize(R.dimen.dp_80);
                int height = ViewGroup.LayoutParams.MATCH_PARENT;
                SwipeMenuItem deleteItem = new SwipeMenuItem(AddressListActivity.this)
                        .setBackgroundColor(ContextCompat.getColor(AddressListActivity.this, R.color.red))
                        .setText("删除")
                        .setTextColor(ContextCompat.getColor(AddressListActivity.this, R.color.white))
                        .setTextSize(16)
                        .setHeight(height)
                        .setWidth(width);
                // 在Item右侧添加一个菜单。
                swipeRightMenu.addMenuItem(deleteItem);
            }
        });

        //菜单监听
        rvList.setSwipeMenuItemClickListener(new SwipeMenuItemClickListener() {
            @Override
            public void onItemClick(SwipeMenuBridge menuBridge) {
                // 任何操作必须先关闭菜单，否则可能出现Item菜单打开状态错乱。
                menuBridge.closeMenu();
                int direction = menuBridge.getDirection(); // 左侧还是右侧菜单。
                int adapterPosition = menuBridge.getAdapterPosition(); // RecyclerView的Item的position。
                int menuPosition = menuBridge.getPosition(); // 菜单在RecyclerView的Item中的Position。
                switch (menuPosition) {
                    case 0:
                        ToastUtils.showShort("删除....");
                        addressBeanList.remove(adapterPosition);
                        //请求网络，删除当前地址
                        //mPresenter.deleteAddress("", "");
                        recyclerViewAdapter.notifyDataSetChanged();
                        break;
                    case 1:
                        break;
                }
            }
        });

        //绑定adapter
        recyclerViewAdapter = new RecyclerViewAdapter<AddressBean>(addressBeanList, R.layout.mine_address_item) {
            @Override
            public void bindView(RecyclerViewAdapter.MyViewHolder holder, int position) {
                holder.setTextView(R.id.tv_name, addressBeanList.get(position).getName());
                holder.setTextView(R.id.tv_phone, addressBeanList.get(position).getPhone());
                holder.setTextView(R.id.tv_address, addressBeanList.get(position).getAddress());
                holder.setCheckBox(R.id.cb_toggle, addressBeanList.get(position).isCheck());
            }
        };
        rvList.setAdapter(recyclerViewAdapter);
        recyclerViewAdapter.setOnItemCheckListener(new RecyclerViewAdapter.OnItemCheckListener() {
            @Override
            public void onItemCheck(int pos) {
                for (int i = 0; i < addressBeanList.size(); i++) {
                    AddressBean addressBean = addressBeanList.get(i);
                    if (i == pos) {
                        addressBean.setCheck(true);
                    } else {
                        addressBean.setCheck(false);
                    }
                }
                //请求网络，更改默认地址状态
//                mPresenter.updateDefaultAddress("", "");
                rvList.post(new Runnable() {
                    @Override
                    public void run() {
                        recyclerViewAdapter.notifyDataSetChanged();
                    }
                });
            }
        });

    }


    @OnClick({R.id.tv_right_menu})
    public void onViewClicked(View view) {
        switch (view.getId()) {
            case R.id.tv_right_menu:
                Toast.makeText(AddressListActivity.this, "新增...", Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(AddressListActivity.this, MineAddressActivity.class);
                Bundle bundle = new Bundle();
                bundle.putBoolean("add", true);
                bundle.putBoolean("edit", false);
                intent.putExtras(bundle);
                ActivityUtils.startActivity(intent);
                break;
        }
    }

}
