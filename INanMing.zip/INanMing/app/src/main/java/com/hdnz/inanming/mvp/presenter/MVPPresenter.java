package com.hdnz.inanming.mvp.presenter;

import com.blankj.utilcode.util.LogUtils;
import com.blankj.utilcode.util.ToastUtils;
import com.hdnz.inanming.mvp.contract.MVPContract;
import com.tsienlibrary.bean.CommonBean;
import com.hdnz.inanming.mvp.model.HttpManager;
import com.tbruyelle.rxpermissions2.RxPermissions;
import com.tsienlibrary.mvp.base.BasePresenterImpl;

import java.io.File;
import java.io.IOException;
import java.util.List;

import io.reactivex.Observer;
import io.reactivex.disposables.Disposable;
import okhttp3.ResponseBody;

/**
 * <pre>
 *     author : Tsien
 *     e-mail : 974490643@qq.com
 *     time   : 2018/10/27
 *     desc   :
 * </pre>
 */
public class MVPPresenter extends BasePresenterImpl<MVPContract.View> implements MVPContract.Presenter {

    @Override
    public void request(String requestUrl, String jsonData, Class clazz) {
        if (!mView.isConnectedNet()) {
            //请求接口前判断是否可以正常访问接口
            return;
        }

        HttpManager.getHttpManager().postJson(requestUrl, jsonData, new Observer<ResponseBody>() {
            @Override
            public void onSubscribe(Disposable d) {
                LogUtils.i("onSubscribe==========");
            }

            @Override
            public void onNext(ResponseBody responseBody) {
                LogUtils.i("onNext==========");
                try {
                    String jsons = responseBody.string();
                    CommonBean commonBean = CommonBean.fromJson(jsons, clazz);
                    if (commonBean.getCode() == 200) {
                        if (mView != null) {
                            mView.requestSuccess(requestUrl, commonBean);
                        }
                    } else {
                        if (mView != null) {
                            mView.requestFail(requestUrl, "CODE:" + commonBean.getCode() + " MSG:" + commonBean.getMsg());
                        }
                    }
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }

            @Override
            public void onError(Throwable e) {

                if (mView != null) {
                    mView.requestFail(requestUrl, e.getMessage());
                }
                LogUtils.i("onError:" + requestUrl + "===" + e.getMessage());
            }

            @Override
            public void onComplete() {
                LogUtils.i("onComplete==========");
            }
        });

    }

    @Override
    public void uploadFiles(String requestUrl, Class clazz, File... files) {

        if (!mView.isConnectedNet()) {
            //请求接口前判断是否可以正常访问接口
            return;
        }

        HttpManager.getHttpManager().uploadFiles(requestUrl, new Observer<ResponseBody>() {
            @Override
            public void onSubscribe(Disposable d) {
                LogUtils.i("onSubscribe==========");
            }

            @Override
            public void onNext(ResponseBody responseBody) {
                LogUtils.i("onNext==========");
                try {
                    String jsons = responseBody.string();
                    CommonBean commonBean = CommonBean.fromJson(jsons, clazz);
                    if (commonBean.getCode() == 200) {
                        if (mView != null) {
                            mView.requestSuccess(requestUrl, commonBean);
                        }
                    } else {
                        if (mView != null) {
                            mView.requestFail(requestUrl, "CODE:" + commonBean.getCode() + " MSG:" + commonBean.getMsg());
                        }
                    }
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }

            @Override
            public void onError(Throwable e) {

                if (mView != null) {
                    mView.requestFail(requestUrl, e.getMessage());
                }
                LogUtils.i("onError:" + requestUrl + "===" + e.getMessage());
            }

            @Override
            public void onComplete() {
                LogUtils.i("onComplete==========");
            }
        }, files);
    }

    @Override
    public void setPermissions(RxPermissions rxPermissions, String... permissions) {
        setPermissions(-1, rxPermissions, permissions);//不设置type,则默认-1
    }

    @Override
    public void setPermissions(final int type, RxPermissions rxPermissions, String... permissions) {

        rxPermissions
                .requestEachCombined(permissions)
                .subscribe(permission -> { // will emit 1 Permission object
                    if (permission.granted) {
                        // All permissions are granted !
//                        ToastUtils.showLong("所有请求的权限都被授予");
                        if (mView != null) {
                            mView.permissionsAreGranted(type);
                        }
                    } else if (permission.shouldShowRequestPermissionRationale) {
                        // At least one denied permission without ask never again
                        ToastUtils.showLong("未经请求而被拒绝");
//                        if (mView != null) {
//                            mView.goToSettings();
//                        }
                    } else {
                        // At least one denied permission with ask never again
                        // Need to go to the settings
                        if (mView != null) {
                            mView.goToSettings();
                        }
                        ToastUtils.showLong("至少有一个人拒绝批准，但要求永远不再\n" +
                                "需要去设置");
                    }
                });


//        rxPermissions
//                .requestEachCombined(Manifest.permission.CAMERA, Manifest.permission.READ_PHONE_STATE)
//                .subscribe(new Consumer<Permission>() {
//                               @Override
//                               public void accept(Permission permission) throws Exception {
//                                   if (permission.granted) {
//                                   } else if (permission.shouldShowRequestPermissionRationale) {
//                                       // Denied permission without ask never again
//                                   } else {
//                                       // Denied permission with ask never again
//                                       // Need to go to the settings
//                                   }
//                               }
//                           }, new Consumer<Throwable>() {
//                               @Override
//                               public void accept(Throwable t) {
//                                   LogUtils.e(TAG, "onError", t);
//                               }
//                           },
//                        new Action() {
//                            @Override
//                            public void run() {
//                                LogUtils.i(TAG, "OnComplete");
//                            }
//                        });
    }
}
