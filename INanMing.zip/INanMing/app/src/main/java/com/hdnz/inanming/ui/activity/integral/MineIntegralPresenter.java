package com.hdnz.inanming.ui.activity.integral;

import com.google.gson.Gson;
import com.hdnz.inanming.mvp.model.HttpManager;
import com.hdnz.inanming.bean.IntegralBean;
import com.hdnz.inanming.bean.TabBannerBean;
import com.tsienlibrary.mvp.base.BasePresenterImpl;

import io.reactivex.Observer;
import io.reactivex.disposables.Disposable;

/**
 * Copyright (C), 2017-2018, 华电南自（贵州）科技有限公司
 * FileName:    MineIntegralPresenter.java
 * Author:      肖昕
 * Email:       xiaox@huadiannanzi.com
 * Date:        2018-11-22 11:31
 * Description: 我的积分activity业务处理类
 * Version:     V1.0.0
 * History:     历史信息
 */
public class MineIntegralPresenter extends BasePresenterImpl<MineIntegralContract.View> implements MineIntegralContract.Presenter {
    @Override
    public void getTabsAndBanner(String url, String josn) {
        HttpManager.getHttpManager().getMethod(url, new Observer<String>() {
            @Override
            public void onSubscribe(Disposable d) {

            }

            @Override
            public void onNext(String json) {
                Gson gson = new Gson();
                TabBannerBean tabBannerBean = gson.fromJson(json, TabBannerBean.class);
                if (null != mView) {
                    mView.requestSuccess(tabBannerBean);
                }
            }

            @Override
            public void onError(Throwable e) {
                if (null != mView) {
                    mView.requestFail("error", url);
                }
            }

            @Override
            public void onComplete() {

            }
        });
    }

    @Override
    public void getIntegralList(String url, String josn, String type, Integer start, Integer end) {
        HttpManager.getHttpManager().getMethod(url + "?type=" + type, new Observer<String>() {
            @Override
            public void onSubscribe(Disposable d) {

            }

            @Override
            public void onNext(String json) {
                Gson gson = new Gson();
                IntegralBean integralBean = gson.fromJson(json, IntegralBean.class);
                if (null != mView) {
                    mView.requestSuccessList(integralBean);
                }
            }

            @Override
            public void onError(Throwable e) {
                if (null != mView) {
                    mView.requestFail("error", url);
                }
            }

            @Override
            public void onComplete() {

            }
        });
    }
}
