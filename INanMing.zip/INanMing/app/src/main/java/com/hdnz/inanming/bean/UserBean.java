package com.hdnz.inanming.bean;

import java.util.List;

/**
 * <pre>
 *     author : Tsien
 *     e-mail : 974490643@qq.com
 *     time   : 2018/12/17
 *     desc   :
 * </pre>
 */
public class UserBean {


    /**
     * userAccountEntity : {"id":"d826585cb2814ceaae4817929ef849ef","userName":"123456_1234","email":"mock","phoneNumber":"123456","profilePhotoUrl":"mock","nickName":"mock","signatory":"mock","systemCode":"mock"}
     * tbAdhibitionEntityList : [{"code":"10013","name":"消息","icon":"tuan","url":"http//"},{"code":"10011","name":"首页","icon":"tuan","url":"http//"}]
     * token : 7e00d592c3f748c8aac5a0873b2668f5
     */

    private UserAccountEntityBean userAccountEntity;
    private List<TbAdhibitionEntityListBean> tbAdhibitionEntityList;
    private String token;
    private String smsCode;

    public String getToken() {
        return token;
    }

    public void setToken(String token) {
        this.token = token;
    }

    public String getSmsCode() {
        return smsCode;
    }

    public void setSmsCode(String smsCode) {
        this.smsCode = smsCode;
    }

    public UserAccountEntityBean getUserAccountEntity() {
        return userAccountEntity;
    }

    public void setUserAccountEntity(UserAccountEntityBean userAccountEntity) {
        this.userAccountEntity = userAccountEntity;
    }


    public List<TbAdhibitionEntityListBean> getTbAdhibitionEntityList() {
        return tbAdhibitionEntityList;
    }

    public void setTbAdhibitionEntityList(List<TbAdhibitionEntityListBean> tbAdhibitionEntityList) {
        this.tbAdhibitionEntityList = tbAdhibitionEntityList;
    }

    public static class UserAccountEntityBean {
        /**
         * id : d826585cb2814ceaae4817929ef849ef
         * userName : 123456_1234
         * email : mock
         * phoneNumber : 123456
         * profilePhotoUrl : mock
         * nickName : mock
         * signatory : mock
         * systemCode : mock
         */

        private String id;
        private String userName;
        private String email;
        private String phoneNumber;
        private String profilePhotoUrl;
        private String nickName;
        private String signatory;
        private String systemCode;

        public String getId() {
            return id;
        }

        public void setId(String id) {
            this.id = id;
        }

        public String getUserName() {
            return userName;
        }

        public void setUserName(String userName) {
            this.userName = userName;
        }

        public String getEmail() {
            return email;
        }

        public void setEmail(String email) {
            this.email = email;
        }

        public String getPhoneNumber() {
            return phoneNumber;
        }

        public void setPhoneNumber(String phoneNumber) {
            this.phoneNumber = phoneNumber;
        }

        public String getProfilePhotoUrl() {
            return profilePhotoUrl;
        }

        public void setProfilePhotoUrl(String profilePhotoUrl) {
            this.profilePhotoUrl = profilePhotoUrl;
        }

        public String getNickName() {
            return nickName;
        }

        public void setNickName(String nickName) {
            this.nickName = nickName;
        }

        public String getSignatory() {
            return signatory;
        }

        public void setSignatory(String signatory) {
            this.signatory = signatory;
        }

        public String getSystemCode() {
            return systemCode;
        }

        public void setSystemCode(String systemCode) {
            this.systemCode = systemCode;
        }

    }

    public static class TbAdhibitionEntityListBean {
        /**
         * code : 10013
         * name : 消息
         * icon : tuan
         * url : http//
         */

        private String adhCode;
        private String name;
        private String icon;
        private String url;

        public String getAdhCode() {
            return adhCode;
        }

        public void setAdhCode(String adhCode) {
            this.adhCode = adhCode;
        }

        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }

        public String getIcon() {
            return icon;
        }

        public void setIcon(String icon) {
            this.icon = icon;
        }

        public String getUrl() {
            return url;
        }

        public void setUrl(String url) {
            this.url = url;
        }
    }
}
