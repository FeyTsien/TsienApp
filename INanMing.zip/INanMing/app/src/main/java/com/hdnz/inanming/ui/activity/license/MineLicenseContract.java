package com.hdnz.inanming.ui.activity.license;

import com.tsienlibrary.mvp.base.BasePresenter;
import com.tsienlibrary.mvp.base.BaseView;

import java.io.File;
import java.util.List;

/**
 * Copyright (C), 2017-2018, 华电南自（贵州）科技有限公司
 * FileName:    MineLicenseContract.java
 * Author:      肖昕
 * Email:       xiaox@huadiannanzi.com
 * Date:        2018-11-12 10:51
 * Description: 我的证照契约接口
 * Version:     V1.0.0
 * History:     历史信息
 */
public interface MineLicenseContract {
    /**
     * 视图接口
     */
    interface View<T> extends BaseView {
        //请求成功后调用
        void requestSuccess(T t);

        //请求失败后调用
        void requestFail(String msg);
    }

    /**
     * 获取我的证照接口
     */
    interface LicensePresenter extends BasePresenter<View> {
        /**
         * 获取所有证照list
         *
         * @param url
         * @param json
         */
        void getListLicense(String url, String json);

        /**
         * 根据证件类型，获取图片数据
         *
         * @param url
         * @param type
         * @param json
         */
        void getLicenseByType(String url, String type, String json);

        /**
         * 上传单张图片文件
         *
         * @param url
         * @param file
         * @param json
         */
        void uploadImageFile(String url, File file, String json);

        /**
         * 上传多张图片文件
         *
         * @param url
         * @param files
         * @param json
         */
        void uploadImageFiles(String url, List<File> files, String json);
    }
}
