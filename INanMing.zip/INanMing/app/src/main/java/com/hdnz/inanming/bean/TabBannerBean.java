package com.hdnz.inanming.bean;

import java.util.List;

/**
 * Copyright (C), 2017-2018, 华电南自（贵州）科技有限公司
 * FileName:    TabBannerBean.java
 * Author:      肖昕
 * Email:       xiaox@huadiannanzi.com
 * Date:        2018-11-26 10:46
 * Description:
 * Version:     V1.0.0
 * History:     历史信息
 */
public class TabBannerBean {

    /**
     * data : {"tab":{"tab":["2018年1月","2月","3月","4月","5月","6月","7月","8月","9月","10月","11月","12月"]},"banner":{"banner":[{"title":"任务奖励","number":"138"},{"title":"消费积分","number":"84"},{"title":"任务积分","number":"97"}]}}
     * code : 200
     * message : success
     * status : true
     */

    private DataBean data;
    private int code;
    private String message;
    private boolean status;

    public DataBean getData() {
        return data;
    }

    public void setData(DataBean data) {
        this.data = data;
    }

    public int getCode() {
        return code;
    }

    public void setCode(int code) {
        this.code = code;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public boolean isStatus() {
        return status;
    }

    public void setStatus(boolean status) {
        this.status = status;
    }

    public static class DataBean {
        /**
         * tab : {"tab":["2018年1月","2月","3月","4月","5月","6月","7月","8月","9月","10月","11月","12月"]}
         * banner : {"banner":[{"title":"任务奖励","number":"138"},{"title":"消费积分","number":"84"},{"title":"任务积分","number":"97"}]}
         */

        private TabBean tab;
        private BannerBean banner;

        public TabBean getTab() {
            return tab;
        }

        public void setTab(TabBean tab) {
            this.tab = tab;
        }

        public BannerBean getBanner() {
            return banner;
        }

        public void setBanner(BannerBean banner) {
            this.banner = banner;
        }

        public static class TabBean {
            private List<String> tab;

            public List<String> getTab() {
                return tab;
            }

            public void setTab(List<String> tab) {
                this.tab = tab;
            }
        }

        public static class BannerBean {
            private List<Banner> banner;

            public List<Banner> getBanner() {
                return banner;
            }

            public void setBanner(List<Banner> banner) {
                this.banner = banner;
            }

            public static class Banner {
                /**
                 * title : 任务奖励
                 * number : 138
                 */

                private String title;
                private String number;

                public String getTitle() {
                    return title;
                }

                public void setTitle(String title) {
                    this.title = title;
                }

                public String getNumber() {
                    return number;
                }

                public void setNumber(String number) {
                    this.number = number;
                }
            }
        }
    }
}
