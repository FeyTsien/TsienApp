package com.hdnz.inanming.ui.activity.license;

import com.google.gson.Gson;
import com.tsienlibrary.mvp.base.BasePresenterImpl;
import com.hdnz.inanming.bean.LicenseBean;
import com.hdnz.inanming.bean.LicenseImgBean;
import com.hdnz.inanming.mvp.model.HttpManager;

import java.io.File;
import java.util.List;

import io.reactivex.Observer;
import io.reactivex.disposables.Disposable;

/**
 * Copyright (C), 2017-2018, 华电南自（贵州）科技有限公司
 * FileName:    MineLicensePresenter.java
 * Author:      肖昕
 * Email:       xiaox@huadiannanzi.com
 * Date:        2018-11-12 10:50
 * Description: 我的证照业务处理类
 * Version:     V1.0.0
 * History:     历史信息
 */
public class MineLicensePresenter extends BasePresenterImpl<MineLicenseContract.View> implements MineLicenseContract.LicensePresenter {
    @Override
    public void getListLicense(String url, String json) {
        HttpManager.getHttpManager().getMethod(url, new Observer<String>() {
            @Override
            public void onSubscribe(Disposable d) {

            }

            @Override
            public void onNext(String s) {
                Gson gson = new Gson();
                LicenseBean licenseBean = gson.fromJson(s, LicenseBean.class);
                if (null != mView) {
                    mView.requestSuccess(licenseBean);
                }
            }

            @Override
            public void onError(Throwable e) {
                if (null != mView) {
                    mView.requestFail("error");
                }
            }

            @Override
            public void onComplete() {

            }
        });
    }

    @Override
    public void getLicenseByType(String url, final String type, String json) {
        HttpManager.getHttpManager().getMethod(url, new Observer<String>() {
            @Override
            public void onSubscribe(Disposable d) {

            }

            @Override
            public void onNext(String s) {
                //判断类型返回不同数据
                Gson gson = new Gson();
                LicenseImgBean licenseImgBean = gson.fromJson(s, LicenseImgBean.class);
                if (null != mView) {
                    mView.requestSuccess(licenseImgBean);
                }
            }

            @Override
            public void onError(Throwable e) {
                if (null != mView) {
                    mView.requestFail("error");
                }
            }

            @Override
            public void onComplete() {

            }
        });
    }

    @Override
    public void uploadImageFile(String url, File file, String json) {

    }

    @Override
    public void uploadImageFiles(String url, List<File> files, String json) {

    }
}
