package com.hdnz.inanming.ui.activity.certification.idCard;

import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Environment;
import android.support.v7.widget.Toolbar;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.View;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.baidu.ocr.sdk.OCR;
import com.baidu.ocr.sdk.OnResultListener;
import com.baidu.ocr.sdk.exception.OCRError;
import com.baidu.ocr.sdk.model.IDCardParams;
import com.baidu.ocr.sdk.model.IDCardResult;
import com.baidu.ocr.ui.camera.CameraActivity;
import com.baidu.ocr.ui.camera.CameraNativeHelper;
import com.baidu.ocr.ui.camera.CameraView;
import com.blankj.utilcode.util.LogUtils;
import com.blankj.utilcode.util.ToastUtils;
import com.hdnz.inanming.R;
import com.hdnz.inanming.app.GlideApp;
import com.hdnz.inanming.bean.ImageBean;
import com.hdnz.inanming.mvp.contract.MVPContract;
import com.hdnz.inanming.mvp.presenter.MVPPresenter;
import com.hdnz.inanming.mvp.view.MVPActivity;
import com.hdnz.inanming.utils.FileUtil;
import com.hdnz.inanming.utils.TempFileHelper;
import com.hdnz.inanming.utils.UrlUtils;
import com.tbruyelle.rxpermissions2.RxPermissions;
import com.tsienlibrary.utils.OpenFileUtils;

import java.io.File;
import java.io.IOException;

import butterknife.BindView;
import butterknife.OnClick;
import cn.bingoogolapple.photopicker.util.BGAPhotoHelper;
import cn.bingoogolapple.photopicker.util.BGAPhotoPickerUtil;
import razerdp.basepopup.QuickPopupBuilder;
import razerdp.basepopup.QuickPopupConfig;
import razerdp.widget.QuickPopup;

/**
 * Copyright (C), 2017-2018, 华电南自（贵州）科技有限公司
 * FileName:    IdCardAuthenticationActivity.java
 * Author:      肖昕
 * Email:       xiaox@huadiannanzi.com
 * Date:        2018-11-08 16:09
 * Description: 身份证实名认证activity
 * Version:     V1.0.0
 * History:     历史信息
 */
public class IdCardAuthenticationActivity extends MVPActivity<MVPContract.View, MVPPresenter>
        implements MVPContract.View {

    //从图片库选择图片
    private static final int REQUEST_CODE_CHOOSE_PHOTO = 1;
    //调用相机拍照
    private static final int REQUEST_CODE_TAKE_PHOTO = 2;
    //裁剪图片
    private static final int REQUEST_CODE_CROP = 3;

    private static final int REQUEST_CODE_PICK_IMAGE_FRONT = 201;
    private static final int REQUEST_CODE_PICK_IMAGE_BACK = 202;
    //@field OCR拍照完成的结果吗
    private static final int REQUEST_CODE_CAMERA = 102;

    private BGAPhotoHelper mPhotoHelper;
    private TempFileHelper tempFileHelper;
    private QuickPopup mQuickPopup;//PopupWindow
    @BindView(R.id.tv_title)
    TextView tvTitle;
    @BindView(R.id.tv_right_menu)
    TextView tvRightMenu;
    @BindView(R.id.toolbar)
    Toolbar mToolbar;

    @BindView(R.id.rl_idcard_face_hide)
    RelativeLayout rlIdcardFaceHide;
    @BindView(R.id.iv_idcard_side_front)
    ImageView ivIdcardSideFront;
    @BindView(R.id.rl_idcard_face)
    RelativeLayout rlIdcardFace;

    @BindView(R.id.rl_idcard_reverse_hide)
    RelativeLayout rlIdcardReverseHide;
    @BindView(R.id.iv_idcard_side_back)
    ImageView ivIdcardSideBack;
    @BindView(R.id.rl_idcard_reverse)
    RelativeLayout rlIdcardReverse;

    @BindView(R.id.rl_idcard_hand_hide)
    RelativeLayout rlIdcardHandHide;
    @BindView(R.id.iv_hand_idcard)
    ImageView ivHandIdcard;
    @BindView(R.id.rl_idcard_hand)
    RelativeLayout rlIdcardHand;

    @Override
    protected int getLayoutId() {
        return R.layout.activity_id_card_authentication;
    }

    @Override
    protected void initData() {

        // 拍照后照片的存放目录，改成你自己拍照后要存放照片的目录。如果不传递该参数的话就没有拍照功能
        File takePhotoDir = new File(Environment.getExternalStorageDirectory(), OpenFileUtils.getApkPath(this));
        mPhotoHelper = new BGAPhotoHelper(takePhotoDir);
        tempFileHelper = new TempFileHelper(takePhotoDir);

        //  初始化百度OCR本地质量控制模型,释放代码在onDestory中
        //  调用身份证扫描必须加上 intent.putExtra(CameraActivity.KEY_NATIVE_MANUAL, true); 关闭自动初始化和释放本地模型
        CameraNativeHelper.init(this, OCR.getInstance(this).getLicense(),
                (errorCode, e) -> {
                    String msg;
                    switch (errorCode) {
                        case CameraView.NATIVE_SOLOAD_FAIL:
                            msg = "加载so失败，请确保apk中存在ui部分的so";
                            break;
                        case CameraView.NATIVE_AUTH_FAIL:
                            msg = "授权本地质量控制，token获取失败";
                            break;
                        case CameraView.NATIVE_INIT_FAIL:
                            msg = "授权本地质量控制，模型加载失败";
                            break;
                        default:
                            msg = String.valueOf(errorCode);
                    }
                    LogUtils.e("本地质量控制初始化错误，错误原因： " + msg);
                });
    }

    /**
     * 初始化
     */
    @Override
    protected void initView() {
        //设置title
        setToolBar(mToolbar, tvTitle, getResources().getString(R.string.idcard_real_authentication));
        tvRightMenu.setVisibility(View.VISIBLE);
        //设置save文本
        tvRightMenu.setText(R.string.save);

    }

    @Override
    protected void onDestroy() {
        // 释放本地质量控制模型
        CameraNativeHelper.release();
        super.onDestroy();
    }

    @OnClick({R.id.rl_idcard_face, R.id.rl_idcard_reverse, R.id.rl_idcard_hand, R.id.tv_right_menu})
    public void onViewClicked(View view) {
        switch (view.getId()) {
            case R.id.rl_idcard_face:
                setPermissions(R.id.rl_idcard_face);
                break;
            case R.id.rl_idcard_reverse:
                setPermissions(R.id.rl_idcard_reverse);
                break;
            case R.id.rl_idcard_hand:
                setPermissions(R.id.rl_idcard_hand);
                break;
            case R.id.tv_right_menu:
                ToastUtils.showShort("保存");
                break;
        }
    }

    /**
     * TODO:动态获取权限
     *
     * @param type
     */
    private void setPermissions(int type) {
        RxPermissions rxPermissions = new RxPermissions(this);
        String[] permissions = {Manifest.permission.WRITE_EXTERNAL_STORAGE, Manifest.permission.CAMERA};
        mPresenter.setPermissions(type, rxPermissions, permissions);
    }

    @Override
    public void permissionsAreGranted(int type) {
        switch (type) {
            case R.id.rl_idcard_face:
                //身份证正面照
                takePhotosCOR1(CameraActivity.CONTENT_TYPE_ID_CARD_FRONT);
//                takePhotosCOR2(CameraActivity.CONTENT_TYPE_ID_CARD_FRONT);
                break;
            case R.id.rl_idcard_reverse:
                //身份证反面照
//                takePhotosCOR1(CameraActivity.CONTENT_TYPE_ID_CARD_BACK);
                takePhotosCOR2(CameraActivity.CONTENT_TYPE_ID_CARD_BACK);
                break;
            case R.id.rl_idcard_hand:
                //手持身份证拍照
                mQuickPopup = QuickPopupBuilder.with(getContext())
                        .contentView(R.layout.popup_select_photo)
                        .config(new QuickPopupConfig()
                                .gravity(Gravity.RIGHT | Gravity.CENTER_VERTICAL)
                                .withClick(R.id.tv_camera, new View.OnClickListener() {
                                    @Override
                                    public void onClick(View v) {
                                        takePhoto();
                                    }
                                }).withClick(R.id.tv_photos, new View.OnClickListener() {
                                    @Override
                                    public void onClick(View v) {
                                        choosePhoto();
                                    }
                                }).withClick(R.id.tv_cancel, new View.OnClickListener() {
                                    @Override
                                    public void onClick(View v) {
                                        mQuickPopup.dismiss();
                                    }
                                })
                        ).show();
                break;
        }
    }

    /**
     * 手动执行拍照（百度OCR UI）
     *
     * @param type
     */
    private void takePhotosCOR1(String type) {
        Intent intent = new Intent(this, CameraActivity.class);
//        intent.putExtra(CameraActivity.KEY_OUTPUT_FILE_PATH, FileUtil.getSaveFile(getApplication()).getAbsolutePath());
        try {
            intent.putExtra(CameraActivity.KEY_OUTPUT_FILE_PATH, tempFileHelper.createCameraFile().getAbsolutePath());
        } catch (IOException e) {
            e.printStackTrace();
        }
        intent.putExtra(CameraActivity.KEY_CONTENT_TYPE, type);
        startActivityForResult(intent, REQUEST_CODE_CAMERA);
    }

    /**
     * 自动识别拍照（百度OCR UI）
     *
     * @param type
     */
    private void takePhotosCOR2(String type) {
        Intent intent = new Intent(this, CameraActivity.class);
//        intent.putExtra(CameraActivity.KEY_OUTPUT_FILE_PATH, OpenFileUtils.getImagePath(this));
        try {
            intent.putExtra(CameraActivity.KEY_OUTPUT_FILE_PATH, tempFileHelper.createCameraFile().getAbsolutePath());
        } catch (IOException e) {
            e.printStackTrace();
        }
        intent.putExtra(CameraActivity.KEY_NATIVE_ENABLE, true);
        // KEY_NATIVE_MANUAL设置了之后CameraActivity中不再自动初始化和释放模型
        // 请手动使用CameraNativeHelper初始化和释放模型
        // 推荐这样做，可以避免一些activity切换导致的不必要的异常
        intent.putExtra(CameraActivity.KEY_NATIVE_MANUAL,
                true);
        intent.putExtra(CameraActivity.KEY_CONTENT_TYPE, type);
        startActivityForResult(intent, REQUEST_CODE_CAMERA);
    }

    /**
     * 从图片库选择图片
     */
    public void choosePhoto() {
        startActivityForResult(mPhotoHelper.getChooseSystemGalleryIntent(), REQUEST_CODE_CHOOSE_PHOTO);
    }

    /**
     * 调用相机拍照
     */
    public void takePhoto() {
        try {
            startActivityForResult(mPhotoHelper.getTakePhotoIntent(), REQUEST_CODE_TAKE_PHOTO);
        } catch (Exception e) {
            BGAPhotoPickerUtil.show(R.string.bga_pp_not_support_take_photo);
        }
    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        idcardSideFrontAndrBack(requestCode, resultCode, data);
        handIdcard(requestCode, resultCode, data);

    }

    /**
     * 选择身份证正反面的回调
     *
     * @param resultCode
     * @param requestCode
     * @param data
     */
    private void idcardSideFrontAndrBack(int requestCode, int resultCode, Intent data) {

//        if (requestCode == REQUEST_CODE_PICK_IMAGE_FRONT && resultCode == Activity.RESULT_OK) {
//            Uri uri = data.getData();
//            String filePath =  FileUtil.getRealPathFromURI(mContext, uri);
//            recIDCard(IDCardParams.ID_CARD_SIDE_FRONT, filePath);
//        }
//
//        if (requestCode == REQUEST_CODE_PICK_IMAGE_BACK && resultCode == Activity.RESULT_OK) {
//            Uri uri = data.getData();
//            String filePath =  FileUtil.getRealPathFromURI(mContext, uri);
//            recIDCard(IDCardParams.ID_CARD_SIDE_BACK, filePath);
//        }
        if (requestCode == REQUEST_CODE_CAMERA && resultCode == Activity.RESULT_OK) {
            if (data != null) {
                String contentType = data.getStringExtra(CameraActivity.KEY_CONTENT_TYPE);
//                String filePath = FileUtil.getSaveFile(getApplicationContext()).getAbsolutePath();
                String filePath = tempFileHelper.getCameraFilePath();
                if (!TextUtils.isEmpty(contentType)) {
                    if (CameraActivity.CONTENT_TYPE_ID_CARD_FRONT.equals(contentType)) {
                        mFileSideFront = new File(filePath);
                        recIDCard(IDCardParams.ID_CARD_SIDE_FRONT, filePath, contentType);
                    } else if (CameraActivity.CONTENT_TYPE_ID_CARD_BACK.equals(contentType)) {
                        mFileSideBack = new File(filePath);
                        recIDCard(IDCardParams.ID_CARD_SIDE_BACK, filePath, contentType);
                    }
                }
            }
        }
    }

    private File mFileSideFront;
    private File mFileSideBack;
    private File mFileHandIdcard;

    /**
     * 选择手持身份证照片的回调
     *
     * @param resultCode
     * @param requestCode
     * @param data
     */
    private void handIdcard(int requestCode, int resultCode, Intent data) {
        if (resultCode == RESULT_OK) {
            if (requestCode == REQUEST_CODE_CHOOSE_PHOTO) {
                //从图库选择图片成功
                try {
                    //准备执行裁剪图片
                    startActivityForResult(mPhotoHelper.getCropIntent(mPhotoHelper.getFilePathFromUri(data.getData()), 360, 205), REQUEST_CODE_CROP);
                } catch (Exception e) {
                    mPhotoHelper.deleteCropFile();
                    BGAPhotoPickerUtil.show(R.string.bga_pp_not_support_crop);
                    e.printStackTrace();
                }
            } else if (requestCode == REQUEST_CODE_TAKE_PHOTO) {
                //调用相机，拍摄照片成功
                try {
                    //准备执行裁剪图片
                    startActivityForResult(mPhotoHelper.getCropIntent(mPhotoHelper.getCameraFilePath(), 360, 205), REQUEST_CODE_CROP);
                } catch (Exception e) {
                    mPhotoHelper.deleteCameraFile();
                    mPhotoHelper.deleteCropFile();
                    BGAPhotoPickerUtil.show(R.string.bga_pp_not_support_crop);
                    e.printStackTrace();
                }
            } else if (requestCode == REQUEST_CODE_CROP) {
                //裁剪成功
//                //上传图片
//                mPresenter.uploadFiles(UrlUtils.UPLOAD_IMAGES, ImageBean.class, new File(mPhotoHelper.getCropFilePath()));
                showImage(mPhotoHelper.getCropFilePath(), ivHandIdcard);
                mQuickPopup.dismiss();//关闭Popup
            }
        } else {
            if (requestCode == REQUEST_CODE_CROP) {
                mPhotoHelper.deleteCameraFile();
                mPhotoHelper.deleteCropFile();
            }
        }
    }

    /**
     * 通过OCR识别身份证方法(需要联网)
     *
     * @param idCardSide
     * @param filePath
     */
    private void recIDCard(String idCardSide, String filePath, String contentType) {
        IDCardParams param = new IDCardParams();
        param.setImageFile(new File(filePath));
        // 设置身份证正反面
        param.setIdCardSide(idCardSide);
        // 设置方向检测
        param.setDetectDirection(true);
        // 设置图像参数压缩质量0-100, 越大图像质量越好但是请求时间越长。 不设置则默认值为20
        param.setImageQuality(20);

        OCR.getInstance(this).recognizeIDCard(param, new OnResultListener<IDCardResult>() {
            @Override
            public void onResult(IDCardResult result) {
                if (result != null) {
                    if (CameraActivity.CONTENT_TYPE_ID_CARD_FRONT.equals(contentType)) {
                        showImage(filePath, ivIdcardSideFront);
                    } else if (CameraActivity.CONTENT_TYPE_ID_CARD_BACK.equals(contentType)) {
                        showImage(filePath, ivIdcardSideBack);
                    }
                    LogUtils.i("OCR", result.toString());
                }
            }

            @Override
            public void onError(OCRError error) {
                LogUtils.i("OCR", error.getMessage());
            }
        });
    }


    /**
     * 拍照、选择图片完，展示图片
     *
     * @param uri
     * @param iv
     */
    private void showImage(String uri, ImageView iv) {
        iv.setVisibility(View.VISIBLE);
        GlideApp.with(this)
                .load(uri)
                .placeholder(R.drawable.empty)
                .error(R.drawable.empty)
                .into(iv);
    }

}