package com.hdnz.inanming.ui.activity.transaction.detail;

import android.support.annotation.NonNull;
import android.support.v4.content.ContextCompat;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.hdnz.inanming.R;
import com.hdnz.inanming.bean.TransactionDetail2Bean;
import com.hdnz.inanming.ui.activity.transaction.MineTransactionContract;
import com.hdnz.inanming.ui.activity.transaction.MineTransactionPresenter;
import com.hdnz.inanming.ui.adapter.TransactionDetail2Adapter;
import com.scwang.smartrefresh.layout.SmartRefreshLayout;
import com.scwang.smartrefresh.layout.api.RefreshLayout;
import com.scwang.smartrefresh.layout.listener.OnRefreshListener;
import com.tsienlibrary.mvp.base.MVPBaseActivity;
import com.yanzhenjie.recyclerview.swipe.widget.DefaultItemDecoration;

import java.util.List;

import butterknife.BindView;

/**
 * Copyright (C), 2017-2018, 华电南自（贵州）科技有限公司
 * FileName:    TransactionDetailActivity.java
 * Author:      肖昕
 * Email:       xiaox@huadiannanzi.com
 * Date:        2018-11-20 15:18
 * Description: 查看办理详情（activity）
 * Version:     V1.0.0
 * History:     历史信息
 */
public class TransactionDetail2Activity extends MVPBaseActivity<MineTransactionContract.View, MineTransactionPresenter>
        implements MineTransactionContract.View<TransactionDetail2Bean> {
    @BindView(R.id.tv_title)
    TextView tvTitle;
    @BindView(R.id.tv_right_menu)
    TextView tvRightMenu;
    @BindView(R.id.toolbar)
    Toolbar mToolbar;
    @BindView(R.id.rv_transaction_list)
    RecyclerView rvTransactionList;
    @BindView(R.id.refreshLayout)
    SmartRefreshLayout refreshLayout;
    @BindView(R.id.rl_error_page)
    RelativeLayout rlErrorPage;
    @BindView(R.id.rl_empty_page)
    RelativeLayout rlEmptyPage;
    @BindView(R.id.ll_detail_cont)
    LinearLayout llDetailCont;

    @Override
    protected int getLayoutId() {
        return R.layout.activity_transaction_detail2;
    }

    @Override
    protected void initData() {

    }
    @Override
    protected void  initView() {
        //设置title
        setToolBar(mToolbar, tvTitle, getResources().getString(R.string.view_details));
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(this);
        linearLayoutManager.setOrientation(LinearLayoutManager.VERTICAL);
        rvTransactionList.setLayoutManager(linearLayoutManager);
        rvTransactionList.addItemDecoration(new DefaultItemDecoration(ContextCompat.getColor(this, R.color.me_divider), 1, 1));
        refreshLayout.autoRefresh();
        //下拉刷新
        refreshLayout.setOnRefreshListener(new OnRefreshListener() {
            @Override
            public void onRefresh(@NonNull RefreshLayout refreshLayout) {
                requestData(0);
            }
        });
    }

    /**
     * 请求数据
     *
     * @param type
     */
    private void requestData(int type) {
        mPresenter.seeDetail("transactions2", "", "2");
    }

    @Override
    public void requestSuccess(TransactionDetail2Bean transactionDetail2Bean) {
        rlErrorPage.setVisibility(View.GONE);
        if (null != transactionDetail2Bean.getData()) {
            TransactionDetail2Bean.DataBean dataBean = transactionDetail2Bean.getData();
            //此处开始设置数据
            List<TransactionDetail2Bean.DataBean.MaterialsBean> materials = dataBean.getMaterials();
            if (null != materials && materials.size() > 0) {
                rlEmptyPage.setVisibility(View.GONE);
                llDetailCont.setVisibility(View.VISIBLE);
                TransactionDetail2Adapter adapter = new TransactionDetail2Adapter(this, materials);
                rvTransactionList.setAdapter(adapter);
            } else {
//                rlEmptyPage.setVisibility(View.VISIBLE);
//                llDetailCont.setVisibility(View.GONE);
            }
        } else {
            llDetailCont.setVisibility(View.GONE);
            rlEmptyPage.setVisibility(View.VISIBLE);
        }
        refreshLayout.finishRefresh(200);
    }

    @Override
    public void requestFail(String msg) {
        rlErrorPage.setVisibility(View.VISIBLE);
        llDetailCont.setVisibility(View.GONE);
        rlEmptyPage.setVisibility(View.GONE);
        refreshLayout.finishRefresh(200);
    }
}
