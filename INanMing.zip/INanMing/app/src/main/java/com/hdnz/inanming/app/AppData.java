package com.hdnz.inanming.app;

import android.annotation.SuppressLint;

import com.blankj.utilcode.util.PhoneUtils;
import com.blankj.utilcode.util.SPUtils;
import com.hdnz.inanming.bean.UserBean;

/**
 * Created by Administrator on 2017/8/31.
 */

public class AppData {

    //是否是第一次打开APP
    private static final String KEY_IS_FIRST_OPEN = "is_first_open";
    //是否是新版APP
    private static final String KEY_IS_NEW_APP = "is_new_app";
    //是否登录
    private static final String KEY_IS_LOGIN_ED = "is_logined";
    //Token
    private static final String KEY_TOKEN = "token";
    //UserId
    private static final String KEY_USER_ID = "user_id";
    //手机号
    private static final String KEY_PHONE_NUMBER = "phone_number";
    //邮箱
    private static final String KEY_EMAIL = "email";
    //密码
    private static final String KEY_PASSWORD = "password";
    //头像Url
    private static final String KEY_PORTRAIT_URL = "portrait_url";
    //昵称
    private static final String KEY_NICKNAME = "nickname";
    //个性签名
    private static final String KEY_SIGNATORY = "signatory";
    //Android设备Id
    private static final String KEY_ANDROID_ID = "android_id";
    //是否包含工作台
    private static final String KEY_IS_WORKBENCH = "is_workbench";


    /**
     * 设置是否是最新版APP
     *
     * @param isNewApp
     */
    public static void setNewApp(boolean isNewApp) {
        SPUtils.getInstance().put(KEY_IS_NEW_APP, isNewApp);
    }

    /**
     * 查询是否是最新版APP
     *
     * @return
     */
    public static boolean isNewApp() {
        return SPUtils.getInstance().getBoolean(KEY_IS_NEW_APP, false);
    }


    /**
     * 设置是否登陆
     *
     * @param isLoginEd
     */
    public static void setLogined(boolean isLoginEd) {
        SPUtils.getInstance().put(KEY_IS_LOGIN_ED, isLoginEd);
    }

    /**
     * 查询是否登陆
     *
     * @return
     */
    public static boolean isLogined() {
        return SPUtils.getInstance().getBoolean(KEY_IS_LOGIN_ED, false);
    }

    /**
     * 保存Token
     */
    public static void setToken(String token) {
        SPUtils.getInstance().put(KEY_TOKEN, token);
    }

    /**
     * 获取Token
     */
    public static String getToken() {
        return SPUtils.getInstance().getString(KEY_TOKEN);
    }

    /**
     * 保存UserId
     */
    public static void setUserId(String userId) {
        SPUtils.getInstance().put(KEY_USER_ID, userId);
    }

    /**
     * 获取UserId
     */
    public static String getUserId() {
        return SPUtils.getInstance().getString(KEY_USER_ID);
    }

    /**
     * 保存手机号
     */
    public static void setPhoneNumber(String phoneNumber) {
        SPUtils.getInstance().put(KEY_PHONE_NUMBER, phoneNumber);
    }

    /**
     * 获取手机号
     */
    public static String getPhoneNumber() {
        return SPUtils.getInstance().getString(KEY_PHONE_NUMBER);
    }

    /**
     * 保存密码
     */
    public static void setPassword(String password) {
        SPUtils.getInstance().put(KEY_PASSWORD, password);
    }

    /**
     * 获取密码
     */
    public static String getPassword() {
        return SPUtils.getInstance().getString(KEY_PASSWORD);
    }

    /**
     * 保存头像连接
     */
    public static void setPortraitUrl(String portraitUrl) {
        SPUtils.getInstance().put(KEY_PORTRAIT_URL, portraitUrl);
    }

    /**
     * 获取头像连接
     */
    public static String getPortraitUrl() {
        return SPUtils.getInstance().getString(KEY_PORTRAIT_URL);
    }

    /**
     * 保存昵称
     */
    public static void setNickname(String nickname) {
        SPUtils.getInstance().put(KEY_NICKNAME, nickname);
    }

    /**
     * 获取昵称
     */
    public static String getNickname() {
        return SPUtils.getInstance().getString(KEY_NICKNAME);
    }

    /**
     * 保存个性签名
     */
    public static void setSignatory(String signatory) {
        SPUtils.getInstance().put(KEY_SIGNATORY, signatory);
    }

    /**
     * 获取个性签名
     */
    public static String getSignatory() {
        return SPUtils.getInstance().getString(KEY_SIGNATORY);
    }


    /**
     * 设置是否有工作台
     *
     * @param isNewApp
     */
    public static void setIsWorkBench(boolean isNewApp) {
        SPUtils.getInstance().put(KEY_IS_WORKBENCH, isNewApp);
    }

    /**
     * 查询是否有工作台
     *
     * @return
     */
    public static boolean isWorkBench() {
        return SPUtils.getInstance().getBoolean(KEY_IS_WORKBENCH, false);
    }


    /**
     * 保存手机设备ID
     */
    @SuppressLint("MissingPermission")
    public static void saveAndroidId() {
        SPUtils.getInstance().put(KEY_ANDROID_ID, PhoneUtils.getIMEI());
    }

    /**
     * 获取手机设备ID
     */
    public static String getAndroidId() {
        return SPUtils.getInstance().getString(KEY_ANDROID_ID);
    }

    /**
     * 清除登录信息
     */
    public static void clearLogin() {
        AppData.setLogined(false);
        AppData.setToken("");
        AppData.setUserId("");
        setPhoneNumber("");
        setPassword("");
        AppData.setPortraitUrl("");
        AppData.setNickname("");
        AppData.setSignatory("");
        AppData.setIsWorkBench(false);
    }

    /**
     * 保存登录信息
     *
     * @param userBean
     */
    public static void saveLogin(UserBean userBean) {

        AppData.setLogined(true);
        AppData.setToken(userBean.getToken());
        AppData.setUserId(userBean.getUserAccountEntity().getId());
        AppData.setPhoneNumber(userBean.getUserAccountEntity().getPhoneNumber());
//        AppData.setPassword(password);
        AppData.setPortraitUrl(userBean.getUserAccountEntity().getProfilePhotoUrl());
        AppData.setNickname(userBean.getUserAccountEntity().getNickName());
        AppData.setSignatory(userBean.getUserAccountEntity().getSignatory());
        if (userBean.getTbAdhibitionEntityList().size() > 3) {
            //如果数量大于3个，表明该用户有工作台
            AppData.setIsWorkBench(true);
        } else {
            AppData.setIsWorkBench(false);
        }
    }
}
