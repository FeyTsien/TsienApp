package com.hdnz.inanming.bean;

import java.util.List;

/**
 * Copyright (C), 2017-2018, 华电南自（贵州）科技有限公司
 * FileName:    LicenseBean.java
 * Author:      肖昕
 * Email:       xiaox@huadiannanzi.com
 * Date:        2018-11-12 11:37
 * Description:
 * Version:     V1.0.0
 * History:     历史信息
 */
public class LicenseBean {

    /**
     * data : [{"type":"0","licenseDesc":"身份证","status":true},{"type":"1","licenseDesc":"户口本","status":false},{"type":"2","licenseDesc":"学生证","status":true},{"type":"3","licenseDesc":"一寸照","status":false},{"type":"4","licenseDesc":"双方身份证","status":true},{"type":"5","licenseDesc":"结婚证","status":false},{"type":"6","licenseDesc":"夫妇双方合影照","status":true},{"type":"7","licenseDesc":"XXX登记表","status":false}]
     * code : 200
     * message : sucess
     * status : true
     */

    private int code;
    private String message;
    private boolean status;
    private List<DataBean> data;

    public int getCode() {
        return code;
    }

    public void setCode(int code) {
        this.code = code;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public boolean isStatus() {
        return status;
    }

    public void setStatus(boolean status) {
        this.status = status;
    }

    public List<DataBean> getData() {
        return data;
    }

    public void setData(List<DataBean> data) {
        this.data = data;
    }

    public static class DataBean {
        /**
         * type : 0
         * licenseDesc : 身份证
         * status : true
         */

        private String type;
        private String licenseDesc;
        private boolean status;

        public String getType() {
            return type;
        }

        public void setType(String type) {
            this.type = type;
        }

        public String getLicenseDesc() {
            return licenseDesc;
        }

        public void setLicenseDesc(String licenseDesc) {
            this.licenseDesc = licenseDesc;
        }

        public boolean isStatus() {
            return status;
        }

        public void setStatus(boolean status) {
            this.status = status;
        }
    }

    @Override
    public String toString() {
        return "LicenseBean{" +
                "code=" + code +
                ", message='" + message + '\'' +
                ", status=" + status +
                ", data=" + data +
                '}';
    }
}
