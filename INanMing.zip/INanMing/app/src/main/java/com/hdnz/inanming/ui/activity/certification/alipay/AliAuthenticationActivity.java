package com.hdnz.inanming.ui.activity.certification.alipay;

import android.os.Bundle;

import com.hdnz.inanming.R;
import com.hdnz.inanming.bean.CheckBean;
import com.hdnz.inanming.mvp.contract.MVPContract;
import com.hdnz.inanming.mvp.presenter.MVPPresenter;
import com.hdnz.inanming.mvp.view.MVPActivity;
import com.tsienlibrary.mvp.base.MVPBaseActivity;

/**
 * Copyright (C), 2017-2018, 华电南自（贵州）科技有限公司
 * FileName:    AuthenticationActivity.java
 * Author:      肖昕
 * Email:       xiaox@huadiannanzi.com
 * Date:        2018-11-08 17:22
 * Description: 实名认证activity
 * Version:     V1.0.0
 * History:     历史信息
 */
public class AliAuthenticationActivity extends MVPActivity<MVPContract.View, MVPPresenter> implements MVPContract.View {

    @Override
    protected int getLayoutId() {
        return R.layout.activity_ali_authentication;
    }

    @Override
    protected void initData() {

    }

    @Override
    protected void initView() {

    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

}
