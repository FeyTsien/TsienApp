package com.hdnz.inanming.mvp.view;


import com.blankj.utilcode.util.AppUtils;
import com.blankj.utilcode.util.NetworkUtils;
import com.blankj.utilcode.util.ToastUtils;
import com.hdnz.inanming.mvp.contract.MVPContract;
import com.tsienlibrary.bean.CommonBean;
import com.tsienlibrary.loadsir.callback.NetworkFailureCallback;
import com.tsienlibrary.mvp.base.BasePresenterImpl;
import com.tsienlibrary.mvp.base.BaseView;
import com.tsienlibrary.mvp.base.MVPBaseActivity;

public abstract class MVPActivity<V extends BaseView, T extends BasePresenterImpl<V>> extends MVPBaseActivity<V, T> implements MVPContract.View {


    /**
     * TODO:请求接口前判断是否可以正常访问接口
     *
     * @return
     */
    @Override
    public boolean isConnectedNet() {
        if (!NetworkUtils.isConnected()) {
            //网络故障
            if (mBaseLoadService != null) {
                mBaseLoadService.showCallback(NetworkFailureCallback.class);
            } else {
                ToastUtils.showShort("网络故障");
            }
            return false;
        }
        return true;
    }

    @Override
    public void requestSuccess(String requestUrl, CommonBean commonBean) {

    }

    @Override
    public void requestFail(String requestUrl, String msg) {

    }

    @Override
    public void permissionsAreGranted(int type) {

    }

    @Override
    public void goToSettings() {
        //前往设置界面
        AppUtils.launchAppDetailsSettings();
    }

}
