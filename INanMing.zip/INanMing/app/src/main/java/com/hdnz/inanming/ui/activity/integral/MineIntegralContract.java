package com.hdnz.inanming.ui.activity.integral;

import com.tsienlibrary.mvp.base.BasePresenter;
import com.tsienlibrary.mvp.base.BaseView;

/**
 * Copyright (C), 2017-2018, 华电南自（贵州）科技有限公司
 * FileName:    MineIntegralContract.java
 * Author:      肖昕
 * Email:       xiaox@huadiannanzi.com
 * Date:        2018-11-22 11:25
 * Description: 我的积分契约接口
 * Version:     V1.0.0
 * History:     历史信息
 */
public interface MineIntegralContract {
    /**
     * 视图接口
     *
     * @param <T>
     */
    interface View<T, M> extends BaseView {
        /**
         * 请求成功后调用
         * @param t
         */
        void requestSuccess(T t);

        /**
         * 请求成功后调用
         * @param m
         */
        void requestSuccessList(M m);

        /**
         * 请求失败后调用
         * @param msg
         */
        void requestFail(String msg, String type);
    }

    /**
     * 请求业务接口
     */
    interface Presenter extends BasePresenter<View> {
        /**
         * 获取我的月份tab选项卡和banner数据
         *
         * @param url
         * @param josn
         */
        void getTabsAndBanner(String url, String josn);

        /**
         * 根据不同积分类型，查看积分数据
         *
         * @param url
         * @param josn
         * @param type  积分类型（消费积分、任务积分、任务奖励）
         * @param start
         * @param end
         */
        void getIntegralList(String url, String josn, String type, Integer start, Integer end);
    }
}
