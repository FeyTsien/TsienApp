package com.hdnz.inanming.ui.fragment.workbench;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.design.widget.TabLayout;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v4.view.ViewPager;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.TextView;

import com.blankj.utilcode.util.ActivityUtils;
import com.blankj.utilcode.util.LogUtils;
import com.hdnz.inanming.R;
import com.hdnz.inanming.ui.fragment.home.HomeFragment;
import com.hdnz.inanming.ui.fragment.me.MeFragment;
import com.hdnz.inanming.ui.fragment.message.MessageFragment;
import com.tsienlibrary.bean.CommonBean;
import com.hdnz.inanming.mvp.view.MVPFragment;
import com.hdnz.inanming.bean.AppBean;
import com.hdnz.inanming.mvp.contract.MVPContract;
import com.hdnz.inanming.mvp.presenter.MVPPresenter;
import com.hdnz.inanming.ui.adapter.MyPagerAdapter;
import com.hdnz.inanming.ui.activity.headlinelist.HeadLineActivity;
import com.hdnz.inanming.ui.activity.workbench.CreateTaskActivity;
import com.hdnz.inanming.ui.activity.workbench.TaskSetActivity;
import com.hdnz.inanming.ui.adapter.RecyclerViewAdapter;
import com.hdnz.inanming.ui.fragment.content.ContentFragment;
import com.tsienlibrary.loadsir.callback.ErrorCallback;
import com.tsienlibrary.ui.widget.CustomViewPager;

import java.util.ArrayList;
import java.util.List;

import butterknife.BindView;
import butterknife.OnClick;

/**
 * <pre>
 *     author : Tsien
 *     e-mail : 974490643@qq.com
 *     time   : 2018/10/30
 *     desc   :====== 工作台 ====
 * </pre>
 */
public class WorkbenchFragment extends MVPFragment<MVPContract.View, MVPPresenter> {

//    private String TAG = getClass().getSimpleName();

    private List<Fragment> mFragmentList;
    private List<String> mTitleList;

    List<String> mWokebenchMenuList;


    private RecyclerViewAdapter mWokebenchMenuAdapter;
    @BindView(R.id.recyclerview)
    RecyclerView mRecyclerView;
    @BindView(R.id.tl_task_center)
    TabLayout mTabLayout;
    @BindView(R.id.view_pager)
    CustomViewPager mViewPager;


    public static WorkbenchFragment newInstance() {
        return new WorkbenchFragment();
    }

    @Override
    protected int getLayoutId() {
        return R.layout.fragment_wokebench;
    }

    @Override
    protected void initData() {
        mFragmentList = new ArrayList<>();
        mTitleList = new ArrayList<>();
        mWokebenchMenuList = new ArrayList<>();

        mWokebenchMenuList.add("考勤打卡");
        mWokebenchMenuList.add("汇报");
        mWokebenchMenuList.add("文件");
        mWokebenchMenuList.add("通讯录");
        mWokebenchMenuList.add("数治社工");
        mWokebenchMenuList.add("社区人事");
        mWokebenchMenuList.add("社区政务");

        mTitleList.add("待办任务");
        mTitleList.add("已逾期");
        mTitleList.add("已完成");
        mTitleList.add("全部");
        request();
    }

    @Override
    protected void initView() {
        initRecyclerView();//这个是上面的菜单选项的recyclerView
        initFragment();
        initViewPager();
    }

    /**
     * 工作台菜单表初始化
     */
    private void initRecyclerView() {
        GridLayoutManager layoutManager = new GridLayoutManager(getActivity(), 4);
        layoutManager.setOrientation(LinearLayoutManager.VERTICAL);
        mRecyclerView.setLayoutManager(layoutManager);

        mWokebenchMenuAdapter = new RecyclerViewAdapter<String>(mWokebenchMenuList, R.layout.item_wokebench_menu) {
            @Override
            public void bindView(RecyclerViewAdapter.MyViewHolder holder, int position) {
                holder.setTextView(R.id.text_view, mWokebenchMenuList.get(position));
            }
        };
        mRecyclerView.setAdapter(mWokebenchMenuAdapter);
    }


    /**
     * TODO:初始化部分Fragment
     */
    private void initFragment() {
        mFragmentList.add(TaskFragmentA.newInstance());
        mFragmentList.add(TaskFragmentA.newInstance());
        mFragmentList.add(TaskFragmentA.newInstance());
        mFragmentList.add(TaskFragmentA.newInstance());
    }

    /**
     * TODO:初始化ViewPager(任务中心的四个可切换fragment)
     */
    private void initViewPager() {

        LogUtils.i("WokeBenchF", "mViewPager" + mViewPager);
        MyPagerAdapter myPagerAdapter = new MyPagerAdapter(getChildFragmentManager(), mFragmentList, mTitleList);
        mViewPager.setScanScroll(true);//是否禁止滑动
        mViewPager.setOffscreenPageLimit(3);//预加载几页数据
        mViewPager.setAdapter(myPagerAdapter);
        mTabLayout.setupWithViewPager(mViewPager);//将TabLayout和ViewPager关联起来。
        mTabLayout.removeAllTabs();
        for (int i = 0; i < 4; i++) {
            TabLayout.Tab tab = mTabLayout.newTab();
            View inflate = View.inflate(getActivity(), R.layout.tab_task_center, null);
            ((TextView) inflate.findViewById(R.id.tv_count)).setText("123");
            ((TextView) inflate.findViewById(R.id.tv_tab_title)).setText(mTitleList.get(i));
            tab.setCustomView(inflate);
            mTabLayout.addTab(tab, i);
        }

//        mTabLayout.setTabMode(TabLayout.SCROLL_AXIS_HORIZONTAL);//设置tab模式，当前为系统默认模式
        mViewPager.addOnPageChangeListener(new ViewPager.OnPageChangeListener() {
            @Override
            public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {

//                LogUtils.i("Woke","onPageScrolled" + position);
            }

            @Override
            public void onPageSelected(int position) {
                mTabLayout.setScrollPosition(position, 55f, false);

                LogUtils.i("Woke", "onPageSelected" + position);
                //此处判断选择了哪一页，
                if (position == 0) {
//                    adapter2.notifyDataSetChanged();
                }
            }

            @Override
            public void onPageScrollStateChanged(int state) {
            }
        });
    }

    private void shuaxin(AppBean appBean) {
        //接收到指定数据，刷新
        //mAllList.removeAll(mAllList);
        //mAllList.addAll(appBean.getData());
        // adapter.notifyDataSetChanged();
    }


    @Override
    protected boolean isLoadSir() {
        return true;
    }

    @Override
    protected void request() {
        if (mBaseLoadService != null) {
            //如果有请求接口，可删除
            mBaseLoadService.showSuccess();
        }
        super.request();
    }

    @Override
    public void requestSuccess(String requestUrl, CommonBean commonBean) {
        mBaseLoadService.showSuccess();
    }

    @Override
    public void requestFail(String requestUrl, String msg) {
        mBaseLoadService.showCallback(ErrorCallback.class);
    }

    @OnClick({R.id.tv_headline_list, R.id.tv_create_task, R.id.tv_task_set})
    void onClicks(View view) {
        switch (view.getId()) {
            case R.id.tv_headline_list:
                //打开单位头条
                Intent intent = new Intent(getActivity(), HeadLineActivity.class);
                intent.putExtra(HeadLineActivity.ACTIVITY_TITLE, getResources().getString(R.string.unit_headline));
                startActivity(intent);
                break;
            case R.id.tv_create_task:
                //进入任务设置
                ActivityUtils.startActivity(CreateTaskActivity.class);
                break;
            case R.id.tv_task_set:
                //进入任务设置
                ActivityUtils.startActivity(TaskSetActivity.class);
                break;
        }
    }

}