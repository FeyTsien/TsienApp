package com.hdnz.inanming.ui.activity.transaction;

import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.design.widget.TabLayout;
import android.support.v4.app.Fragment;
import android.support.v4.view.ViewPager;
import android.support.v7.widget.Toolbar;
import android.widget.TextView;

import com.blankj.utilcode.util.LogUtils;
import com.hdnz.inanming.R;
import com.hdnz.inanming.bean.BaseBean;
import com.hdnz.inanming.ui.adapter.MyPagerAdapter;
import com.tsienlibrary.mvp.base.MVPBaseActivity;
import com.hdnz.inanming.ui.fragment.transaction.TransactionFragment;
import com.scwang.smartrefresh.layout.SmartRefreshLayout;
import com.scwang.smartrefresh.layout.api.RefreshLayout;
import com.scwang.smartrefresh.layout.listener.OnRefreshListener;
import com.tsienlibrary.ui.widget.CustomViewPager;

import java.util.ArrayList;
import java.util.List;

import butterknife.BindView;

/**
 * Copyright (C), 2017-2018, 华电南自（贵州）科技有限公司
 * FileName:    MineTransactionActivity.java
 * Author:      肖昕
 * Email:       xiaox@huadiannanzi.com
 * Date:        2018-11-16 09:26
 * Description: 我的办理activity
 * Version:     V1.0.0
 * History:     历史信息
 */
public class MineTransactionActivity extends MVPBaseActivity<MineTransactionContract.View, MineTransactionPresenter>
        implements MineTransactionContract.View<BaseBean> {
    @BindView(R.id.tv_title)
    TextView tvTitle;
    @BindView(R.id.toolbar)
    Toolbar mToolbar;
    @BindView(R.id.tb_navigation)
    TabLayout mTabLayout;
    @BindView(R.id.vp_fragment_container)
    CustomViewPager mViewPager;
    @BindView(R.id.refreshLayout)
    SmartRefreshLayout refreshLayout;

    private List<String> mTitles;
    private List<Fragment> mFragments;

    @Override
    protected int getLayoutId() {
        return R.layout.activity_mine_transaction;
    }


    @Override
    protected void initData() {
        mTitles = new ArrayList<>();
        mFragments = new ArrayList<>();
        //初始化标题
        mTitles.add("全部业务");
        mTitles.add("办理进行");
        mTitles.add("办理完成");
        mTitles.add("办理失败");
        mFragments.add(TransactionFragment.newInstance("1"));
        mFragments.add(TransactionFragment.newInstance("2"));
        mFragments.add(TransactionFragment.newInstance("3"));
        mFragments.add(TransactionFragment.newInstance("4"));
    }

    @Override
    protected void initView() {
        //设置title
        setToolBar(mToolbar, tvTitle, getResources().getString(R.string.my_transaction));
        refreshLayout.setEnableRefresh(false);
        refreshLayout.setOnRefreshListener(new OnRefreshListener() {
            @Override
            public void onRefresh(@NonNull RefreshLayout refreshLayout) {
                //refreshLayout.finishRefresh(500);
            }
        });


        MyPagerAdapter myPagerAdapter = new MyPagerAdapter(getSupportFragmentManager(), mFragments, mTitles);
        mViewPager.setScanScroll(true);//禁止滑动
        mViewPager.setOffscreenPageLimit(0);//预加载几页数据

        for (int i = 0; i < mTitles.size(); i++) {
            TabLayout.Tab tab = mTabLayout.newTab();
            tab.setText(mTitles.get(i));
            mTabLayout.addTab(tab, i);
        }
        mViewPager.setAdapter(myPagerAdapter);
        mTabLayout.setupWithViewPager(mViewPager);//将TabLayout和ViewPager关联起来。
        mTabLayout.setTabMode(TabLayout.SCROLL_AXIS_HORIZONTAL);//设置tab模式，当前为系统默认模式
        mViewPager.addOnPageChangeListener(new ViewPager.OnPageChangeListener() {
            @Override
            public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {
                LogUtils.i("xiaoxin", "onPageScrolled:  " + position);
            }

            @Override
            public void onPageSelected(int position) {
                mTabLayout.setScrollPosition(position, 55f, false);
                LogUtils.e("xiaoxin", "onPageSelected:  " + position);
                //此处判断选择了哪一页
                if (position == 0) {
//                    adapter2.notifyDataSetChanged();
                }
            }

            @Override
            public void onPageScrollStateChanged(int state) {

            }
        });
    }

    @Override
    public void requestSuccess(BaseBean baseBean) {

    }

    @Override
    public void requestFail(String msg) {

    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
    }
}
