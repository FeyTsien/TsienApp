package com.hdnz.inanming.ui.activity;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.widget.DividerItemDecoration;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;

import com.blankj.utilcode.util.LogUtils;
import com.hdnz.inanming.R;
import com.hdnz.inanming.ui.adapter.RecyclerViewAdapter;

import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;

/**
 * <pre>
 *     author : Tsien
 *     e-mail : 974490643@qq.com
 *     time   : 2018/11/01
 *     desc   :
 * </pre>
 */
public class ServerListActivity extends Activity {

    private boolean isShowLog;
    private List<BaseUrl> mBaseUrlList;

    private RecyclerViewAdapter mAdapter;

    @BindView(R.id.recyclerview)
    RecyclerView mRecyclerView;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_server_list);
        ButterKnife.bind(this);
        initView();
    }

    private void init() {
        isShowLog = false;

        LogUtils.Config config = LogUtils.getConfig();
        //logSwitch为false关闭日志
        config.setLogSwitch(isShowLog);
    }

    private void initView() {
        LinearLayoutManager layoutManager = new LinearLayoutManager(this);
        layoutManager.setOrientation(LinearLayoutManager.VERTICAL);
        mRecyclerView.setLayoutManager(layoutManager);
        mRecyclerView.addItemDecoration(new DividerItemDecoration(this, DividerItemDecoration.VERTICAL));

        mAdapter = new RecyclerViewAdapter<BaseUrl>(mBaseUrlList, R.layout.item_server) {
            @Override
            public void bindView(RecyclerViewAdapter.MyViewHolder holder, int position) {
                holder.setTextView(R.id.tv_name, mBaseUrlList.get(position).getName());
            }
        };
        mRecyclerView.setAdapter(mAdapter);
        //item点击事件
        mAdapter.setOnItemClickListener(new RecyclerViewAdapter.OnItemClickListener() {
            @Override
            public void onItemClick(int pos) {
                Intent intent = new Intent(ServerListActivity.this, SplashActivity.class);
                startActivity(intent);
            }
        });
    }

    public enum BaseUrl {
        TEST1("测试环境1", "http://114.215.93.127:9001/dtApi/"),
        DEVELOPMENT("开发环境", "http://114.215.93.127:9001/dtApi/"),
        PRODUCTION("生产环境", "http://114.215.93.127:9001/dtApi/");

        // 成员变量
        private String name;
        private String url;

        // 构造方法
        private BaseUrl(String name, String url) {
            this.name = name;
            this.url = url;
        }

        // 普通方法
        public static String getUrl(String name) {
            for (BaseUrl c : BaseUrl.values()) {
                if (c.getName() == name) {
                    return c.url;
                }
            }
            return null;
        }

        // get set 方法
        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }

        public String getUrl() {
            return url;
        }

        public void setUrl(String url) {
            this.url = url;
        }
    }
}
