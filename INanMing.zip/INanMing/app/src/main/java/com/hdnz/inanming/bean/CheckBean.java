package com.hdnz.inanming.bean;

/**
 * Copyright (C), 2017-2018, 华电南自（贵州）科技有限公司
 * FileName:    CheckBean.java
 * Author:      肖昕
 * Email:       xiaox@huadiannanzi.com
 * Date:        2018-11-09 14:16
 * Description:
 * Version:     V1.0.0
 * History:     历史信息
 */
public class CheckBean {

    /**
     * data : {"type":"身份证","status":"3","user":{"name":"肖昕","sex":"男","address":null,"idcard":null}}
     * code : 200
     * message : success
     * status : true
     */

    private DataBean data;
    private int code;
    private String message;
    private boolean status;

    public DataBean getData() {
        return data;
    }

    public void setData(DataBean data) {
        this.data = data;
    }

    public int getCode() {
        return code;
    }

    public void setCode(int code) {
        this.code = code;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public boolean isStatus() {
        return status;
    }

    public void setStatus(boolean status) {
        this.status = status;
    }

    public static class DataBean {
        /**
         * type : 身份证
         * status : 3
         * user : {"name":"肖昕","sex":"男","address":null,"idcard":null}
         */

        private String type;
        private String status;
        private UserBean user;

        public String getType() {
            return type;
        }

        public void setType(String type) {
            this.type = type;
        }

        public String getStatus() {
            return status;
        }

        public void setStatus(String status) {
            this.status = status;
        }

        public UserBean getUser() {
            return user;
        }

        public void setUser(UserBean user) {
            this.user = user;
        }

        public static class UserBean {
            /**
             * name : 肖昕
             * sex : 男
             * address : null
             * idcard : null
             */

            private String name;
            private String sex;
            private Object address;
            private Object idcard;

            public String getName() {
                return name;
            }

            public void setName(String name) {
                this.name = name;
            }

            public String getSex() {
                return sex;
            }

            public void setSex(String sex) {
                this.sex = sex;
            }

            public Object getAddress() {
                return address;
            }

            public void setAddress(Object address) {
                this.address = address;
            }

            public Object getIdcard() {
                return idcard;
            }

            public void setIdcard(Object idcard) {
                this.idcard = idcard;
            }
        }
    }
}
