package com.hdnz.inanming.ui.activity.reservation;

import android.content.DialogInterface;
import android.graphics.Color;
import android.support.annotation.NonNull;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AlertDialog;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.util.TypedValue;
import android.view.View;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.blankj.utilcode.util.ToastUtils;
import com.hdnz.inanming.R;
import com.hdnz.inanming.app.GlideApp;
import com.hdnz.inanming.bean.BookBean;
import com.hdnz.inanming.ui.adapter.RecyclerViewAdapter;
import com.scwang.smartrefresh.layout.SmartRefreshLayout;
import com.scwang.smartrefresh.layout.api.RefreshLayout;
import com.scwang.smartrefresh.layout.listener.OnLoadMoreListener;
import com.scwang.smartrefresh.layout.listener.OnRefreshListener;
import com.tsienlibrary.mvp.base.MVPBaseActivity;
import com.yanzhenjie.recyclerview.swipe.widget.DefaultItemDecoration;

import java.util.List;

import butterknife.BindView;

/**
 * Copyright (C), 2017-2018, 华电南自（贵州）科技有限公司
 * FileName:    MineBookActivity.java
 * Author:      肖昕
 * Email:       xiaox@huadiannanzi.com
 * Date:        2018-11-26 14:14
 * Description: 我的预约页面(activity)
 * Version:     V1.0.0
 * History:     历史信息
 */
public class MineBookActivity extends MVPBaseActivity<MineBookContract.View, MineBookPresenter>
        implements MineBookContract.View<BookBean> {
    @BindView(R.id.tv_title)
    TextView tvTitle;
    @BindView(R.id.tv_right_menu)
    TextView tvRightMenu;
    @BindView(R.id.toolbar)
    Toolbar mToolbar;
    @BindView(R.id.rv_book_list)
    RecyclerView rvBookList;
    @BindView(R.id.rl_empty_page)
    RelativeLayout rlEmptyPage;
    @BindView(R.id.refreshLayout)
    SmartRefreshLayout refreshLayout;
    /**
     *  @field  刷新类型，0下拉，1上拉
     */
    private int mRefreshType;
    private RecyclerViewAdapter<BookBean.DataBean> adapter;

    @Override
    protected int getLayoutId() {
        return R.layout.activity_mine_book;
    }

    @Override
    protected void initData() {

    }

    @Override
    protected void initView() {
        refreshLayout.autoRefresh();
        //下拉刷新
        refreshLayout.setOnRefreshListener(new OnRefreshListener() {
            @Override
            public void onRefresh(@NonNull RefreshLayout refreshLayout) {
                requestData(0);
            }
        });
        //上拉加载
        refreshLayout.setOnLoadMoreListener(new OnLoadMoreListener() {
            @Override
            public void onLoadMore(@NonNull RefreshLayout refreshLayout) {
                requestData(1);
            }
        });
        //设置title
        setToolBar(mToolbar, tvTitle, getResources().getString(R.string.my_reservation));
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(this);
        linearLayoutManager.setOrientation(LinearLayoutManager.VERTICAL);
        rvBookList.setLayoutManager(linearLayoutManager);
        rvBookList.addItemDecoration(new DefaultItemDecoration(ContextCompat.getColor(this, R.color.me_divider), 1, 1));
    }

    /**
     * 请求数据
     * @param type
     */
    private void requestData(int type) {
        this.mRefreshType = type;
        mPresenter.getBookList("/books", "");
    }

    @Override
    public void requestSuccess(BookBean bookBean) {
        rlEmptyPage.setVisibility(View.GONE);
        rvBookList.setVisibility(View.VISIBLE);

        List<BookBean.DataBean> dataList = bookBean.getData();

        if (mRefreshType == 1) {
            //上拉
            adapter.refresh(dataList);
            refreshLayout.finishLoadMore(500);
        } else {
            adapter = new RecyclerViewAdapter(dataList, R.layout.item_book) {
                @Override
                public void bindView(MyViewHolder holder, int position) {
                    ImageView iv_header = (ImageView) holder.getView(R.id.iv_header);
                    GlideApp.with(MineBookActivity.this)
                            .load(dataList.get(position).getHeadUrl())
                            .placeholder(R.drawable.test)
                            .error(R.drawable.test)
                            .circleCrop()
                            .into(iv_header);
                    holder.setTextView(R.id.tv_bureau, dataList.get(position).getManageUint());
                    holder.setTextView(R.id.tv_prove, dataList.get(position).getProveType());
                    holder.setTextView(R.id.tv_no_tack, dataList.get(position).getTakeNum());
                    holder.setTextView(R.id.tv_tack_num, dataList.get(position).getTakeNum());
                    holder.setTextView(R.id.tv_book_time, dataList.get(position).getBookTime());
                    holder.setTextView(R.id.tv_line_up, dataList.get(position).getLineUpNum());
                    TextView tv_book_cancel = (TextView) holder.getView(R.id.tv_book_cancel);
                    if (dataList.get(position).isStatus()) {
                        tv_book_cancel.setBackground(ContextCompat.getDrawable(MineBookActivity.this, R.drawable.btn_save_shape_selector));
                        tv_book_cancel.setTextColor(ContextCompat.getColor(MineBookActivity.this, R.color.btn_save_selector));
                        tv_book_cancel.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
                        tv_book_cancel.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View view) {
                                AlertDialog.Builder builder = new AlertDialog.Builder(MineBookActivity.this);
                                builder.setTitle("提示")
                                        .setIcon(R.mipmap.ic_logo)
                                        .setMessage("您是否取消当前预约？")
                                        .setPositiveButton("确定", new DialogInterface.OnClickListener() {
                                            @Override
                                            public void onClick(DialogInterface dialogInterface, int i) {
                                                //提交数据
                                                ToastUtils.showShort("正在取消预约");
                                            }
                                        })
                                        .setNeutralButton("取消", new DialogInterface.OnClickListener() {
                                            @Override
                                            public void onClick(DialogInterface dialogInterface, int i) {

                                            }
                                        })
                                        .create()
                                        .show();
                            }
                        });
                    }else {
                        tv_book_cancel.setBackgroundColor(Color.TRANSPARENT);
                        tv_book_cancel.setTextColor(ContextCompat.getColor(MineBookActivity.this, R.color.book_grey));
                        tv_book_cancel.setTextSize(TypedValue.COMPLEX_UNIT_SP, 18);
                    }
                    tv_book_cancel.setText(dataList.get(position).getStatusText());
                }
            };
            rvBookList.setAdapter(adapter);
            refreshLayout.finishRefresh(300);
        }
    }

    @Override
    public void requestFail(String msg) {
        rvBookList.setVisibility(View.GONE);
        rlEmptyPage.setVisibility(View.VISIBLE);
        refreshLayout.finishRefresh(300);
        if (mRefreshType == 1) {
            refreshLayout.finishLoadMore(300);
        }
    }
}
