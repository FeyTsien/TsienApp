package com.hdnz.inanming.ui.fragment.home.govaffairsoffice;

import android.support.annotation.NonNull;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.TextView;

import com.blankj.utilcode.util.ToastUtils;
import com.google.gson.Gson;
import com.hdnz.inanming.R;
import com.hdnz.inanming.bean.HeadLineBean;
import com.hdnz.inanming.bean.RequestBean;
import com.hdnz.inanming.mvp.contract.MVPContract;
import com.hdnz.inanming.mvp.presenter.MVPPresenter;
import com.hdnz.inanming.mvp.view.MVPFragment;
import com.hdnz.inanming.ui.adapter.ListViewAdapter;
import com.hdnz.inanming.ui.adapter.RecyclerViewAdapter;
import com.hdnz.inanming.utils.UrlUtils;
import com.scwang.smartrefresh.layout.SmartRefreshLayout;
import com.scwang.smartrefresh.layout.api.RefreshLayout;
import com.scwang.smartrefresh.layout.listener.OnRefreshLoadMoreListener;
import com.tsienlibrary.bean.CommonBean;

import java.util.ArrayList;
import java.util.List;

import butterknife.BindView;

/**
 * date:2017/6/7
 */


public class GAOThemeFragment extends MVPFragment<MVPContract.View, MVPPresenter> {

    //当前指定页
    private int pageIndex = 1;

    List<String> mThemesList;
    List<String> mThemeItemesList;
    private RecyclerViewAdapter mAdapter;
    private ListViewAdapter mListViewAdapter;

    @BindView(R.id.refresh_layout)
    SmartRefreshLayout mSmartRefreshLayout;
//    @BindView(R.id.recycler_view)
//    RecyclerView mRecyclerView;

    @BindView(R.id.list_view)
    ListView mListView;

    @Override
    protected int getLayoutId() {
        return R.layout.fragment_content_listview;
    }

    @Override
    protected void initData() {
        mThemesList = new ArrayList<>();
        mThemeItemesList = new ArrayList<>();
        mThemesList.add("");
        mThemesList.add("");
        mThemesList.add("");
        mThemesList.add("3");
        mThemesList.add("");
        mThemesList.add("");
        mThemesList.add("");
        mThemesList.add("");
        mThemesList.add("");
        mThemesList.add("");
        mThemesList.add("");
        mThemesList.add("");
        mThemesList.add("");
        mThemesList.add("");
        mThemesList.add("");
        mThemesList.add("");
        mThemesList.add("");
        mThemesList.add("");
        mThemesList.add("");
        mThemesList.add("");
        mThemesList.add("");
        mThemesList.add("");
        mThemesList.add("");
        mThemesList.add("");
        mThemeItemesList.add("2");
        mThemeItemesList.add("23");
        mThemeItemesList.add("33");
        mThemeItemesList.add("223");

    }

    @Override
    protected void initView() {

        //No.1
//        initThemesAdapter();
//        LinearLayoutManager layoutManager = new LinearLayoutManager(getActivity());
//        layoutManager.setOrientation(LinearLayoutManager.VERTICAL);
//        mRecyclerView.setLayoutManager(layoutManager);
//        mRecyclerView.setAdapter(mAdapter);

        //No.2
        mListViewAdapter = getListViewAdapter();
        mListView.setAdapter(mListViewAdapter);
        mListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                ToastUtils.showShort("listView一级菜单" + position + "");
            }
        });

        //下拉刷新
        mSmartRefreshLayout.setOnRefreshLoadMoreListener(new OnRefreshLoadMoreListener() {
            @Override
            public void onLoadMore(@NonNull RefreshLayout refreshLayout) {
                mSmartRefreshLayout.finishLoadMore();
                //上拉加载更多
                pageIndex++;
                request();
            }

            @Override
            public void onRefresh(@NonNull RefreshLayout refreshLayout) {
                //下拉刷新
                pageIndex = 1;
                request();
            }
        });

        request();
    }

//
//    @Override
//    protected boolean isLoadSir() {
//        return true;
//    }

    private ListViewAdapter getListViewAdapter() {
        return new ListViewAdapter<String>(mThemesList, R.layout.item_gao_theme) {
            @Override
            public void bindView(MyViewHolder holder, String title) {
                TextView textView = holder.getView(R.id.tv_title);
                TextView textView2 = holder.getView(R.id.tv_describe);
                textView.setText(title);
                textView2.setText(title);
                RecyclerView recyclerView = holder.getView(R.id.recycler_view);
                if (title.equals("3")) {//如果含有二级菜单则展示这些
                    GridLayoutManager gridLayoutManager = new GridLayoutManager(getContext(), 2){
                        @Override
                        public boolean canScrollVertically() {
                            return false;//禁止滑动
                        }
                    };
                    gridLayoutManager.setOrientation(GridLayoutManager.VERTICAL);
//                    gridLayoutManager.setAutoMeasureEnabled(true);
                    recyclerView.setLayoutManager(gridLayoutManager);
                    recyclerView.setAdapter(getThemeItemAdapter());
                    recyclerView.setVisibility(View.VISIBLE);
                } else {
                    recyclerView.setVisibility(View.GONE);
                }

            }
        };
    }

    /**
     * 初始化一级列表的adapter
     */
    private void initThemesAdapter() {

        mAdapter = new RecyclerViewAdapter<String>(mThemesList, R.layout.item_gao_theme) {
            @Override
            public void bindView(MyViewHolder holder, int position) {
                int size = 1;
                holder.setTextView(R.id.tv_title, mThemesList.get(position));
                holder.setTextView(R.id.tv_describe, mThemesList.get(position));
                RecyclerView recyclerView = holder.getView(R.id.recycler_view);
                if (mThemesList.get(position).equals("3")) {//如果含有二级菜单则展示这些
                    GridLayoutManager gridLayoutManager = new GridLayoutManager(getContext(), 2);
                    gridLayoutManager.setOrientation(GridLayoutManager.VERTICAL);
//                    gridLayoutManager.setAutoMeasureEnabled(true);
                    recyclerView.setLayoutManager(gridLayoutManager);
                    recyclerView.setAdapter(getThemeItemAdapter());
                    recyclerView.setVisibility(View.VISIBLE);
                } else {
                    recyclerView.setVisibility(View.GONE);
                }

                holder.getView(R.id.rl_theme).setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        ToastUtils.showShort("二级菜单" + position + "");
//                        ActivityUtils.startActivity(GovAffairInfoActivity.class);
                    }
                });
            }
        };
    }

    /**
     * 初始化二级列表的adapter
     *
     * @return
     */
    private RecyclerViewAdapter getThemeItemAdapter() {
        RecyclerViewAdapter recyclerViewAdapter = new RecyclerViewAdapter<String>(mThemeItemesList, R.layout.item_gao_theme_item) {
            @Override
            public void bindView(MyViewHolder holder, int position) {
                holder.setTextView(R.id.tv_item, mThemeItemesList.get(position));
            }
        };
        recyclerViewAdapter.setOnItemClickListener(new RecyclerViewAdapter.OnItemClickListener() {
            @Override
            public void onItemClick(int pos) {
                ToastUtils.showShort("二级菜单" + pos + "");
            }
        });
        return recyclerViewAdapter;
    }

    @Override
    protected void request() {
        RequestBean requestBean = new RequestBean();
        RequestBean.PageBean pageBean = new RequestBean.PageBean();
        pageBean.setPageIndex(pageIndex);
        pageBean.setPageSize(10);
        requestBean.setPage(pageBean);
        RequestBean.ParamsBean paramsBean = new RequestBean.ParamsBean();
        paramsBean.setType("3");
        requestBean.setParams(paramsBean);
        Gson gson = new Gson();
        String jsonData = gson.toJson(requestBean);
        mPresenter.request(UrlUtils.COLLECT_SHOPS, jsonData, HeadLineBean.class);
        super.request();
    }

    @Override
    public void requestSuccess(String requestUrl, CommonBean commonBean) {
//
//        //获取到指定list，发送给WokebenchFragment,进行刷新
//        HeadLineBean headLineBean = (HeadLineBean) commonBean.getData();
//        if (pageIndex <= 1) {
//            mSmartRefreshLayout.finishRefresh();
//            if (headLineBean.getRecords().size() == 0) {
//                //没有数据
//                mBaseLoadService.showCallback(NotDataCallback.class);
//                return;
//            }
//            mThemesList.clear();
//            mThemesList.addAll(headLineBean.getRecords());
//        } else {
//            if (pageIndex >= headLineBean.getPages()) {
//                //当前页和总页数相同
//                //完成加载并标记没有更多数据
//                mSmartRefreshLayout.finishLoadMoreWithNoMoreData();
//                pageIndex = headLineBean.getPages();
//            } else {
//                //完成加载
//                mSmartRefreshLayout.finishLoadMore();
//            }
//            mThemesList.addAll(headLineBean.getRecords());
//        }
//        mAdapter.notifyDataSetChanged();
//        mBaseLoadService.showSuccess();
    }

    @Override
    public void requestFail(String requestUrl, String msg) {

    }

    /**
     * fragment静态传值
     */
    public static GAOThemeFragment newInstance() {
        GAOThemeFragment fragment = new GAOThemeFragment();
        return fragment;
    }

}
