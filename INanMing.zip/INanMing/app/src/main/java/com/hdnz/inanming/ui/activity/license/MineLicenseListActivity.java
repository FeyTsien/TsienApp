package com.hdnz.inanming.ui.activity.license;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v4.content.ContextCompat;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.View;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.blankj.utilcode.util.ActivityUtils;
import com.blankj.utilcode.util.ToastUtils;
import com.hdnz.inanming.R;
import com.hdnz.inanming.bean.LicenseBean;
import com.hdnz.inanming.ui.activity.license.detail.LicenseDetailActivity;
import com.hdnz.inanming.ui.adapter.RecyclerViewAdapter;
import com.tsienlibrary.mvp.base.MVPBaseActivity;
import com.scwang.smartrefresh.layout.SmartRefreshLayout;
import com.scwang.smartrefresh.layout.api.RefreshLayout;
import com.scwang.smartrefresh.layout.listener.OnLoadMoreListener;
import com.scwang.smartrefresh.layout.listener.OnRefreshListener;
import com.yanzhenjie.recyclerview.swipe.widget.DefaultItemDecoration;

import java.util.List;

import butterknife.BindView;

/**
 * Copyright (C), 2017-2018, 华电南自（贵州）科技有限公司
 * FileName:    MineLicenseListActivity.java
 * Author:      肖昕
 * Email:       xiaox@huadiannanzi.com
 * Date:        2018-11-12 10:09
 * Description: 我的证照列表activity
 * Version:     V1.0.0
 * History:     历史信息
 */
public class MineLicenseListActivity extends MVPBaseActivity<MineLicenseContract.View, MineLicensePresenter> implements MineLicenseContract.View<LicenseBean> {
    @BindView(R.id.rl_empty_page)
    RelativeLayout rlEmptyPage;
    @BindView(R.id.tv_title)
    TextView tvTitle;
    @BindView(R.id.tv_right_menu)
    TextView tvRightMenu;
    @BindView(R.id.toolbar)
    Toolbar mToolbar;
    @BindView(R.id.rv_license_list)
    RecyclerView rvLicenseList;
    @BindView(R.id.refreshLayout)
    SmartRefreshLayout refreshLayout;
    /**
     * @field adapter
     */
    RecyclerViewAdapter<LicenseBean.DataBean> recyclerViewAdapter;
    /**
     * @field 刷新类型
     */
    private int mRefreshType;

    @Override
    protected int getLayoutId() {
        return R.layout.activity_mine_license_list;
    }

    @Override
    protected void initData() {

    }

    @Override
    protected void initView() {
        refreshLayout.autoRefresh();
        //下拉刷新
        refreshLayout.setOnRefreshListener(new OnRefreshListener() {
            @Override
            public void onRefresh(@NonNull RefreshLayout refreshLayout) {
                requestData(0);
            }
        });
        //上拉加载
        refreshLayout.setOnLoadMoreListener(new OnLoadMoreListener() {
            @Override
            public void onLoadMore(@NonNull RefreshLayout refreshLayout) {
                requestData(1);
            }
        });
        //设置title
        setToolBar(mToolbar, tvTitle, getResources().getString(R.string.my_license));
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(this);
        linearLayoutManager.setOrientation(LinearLayoutManager.VERTICAL);
        rvLicenseList.setLayoutManager(linearLayoutManager);
        rvLicenseList.addItemDecoration(new DefaultItemDecoration(ContextCompat.getColor(this, R.color.me_divider), 1, 1));
    }

    /**
     * 请求数据
     */
    private void requestData(int type) {
        this.mRefreshType = type;
        mPresenter.getListLicense("/license", "");
    }


    @Override
    public void requestSuccess(LicenseBean licenseBean) {
        Log.e("TAG", "requestSuccess: " + licenseBean);
        rlEmptyPage.setVisibility(View.GONE);
        rvLicenseList.setVisibility(View.VISIBLE);
        final List<LicenseBean.DataBean> datas = licenseBean.getData();
        if (mRefreshType == 1) {
            //上拉
            recyclerViewAdapter.refresh(datas);
            refreshLayout.finishLoadMore(800);
        } else {
            recyclerViewAdapter = new RecyclerViewAdapter(datas, R.layout.mine_license_item) {
                @Override
                public void bindView(MyViewHolder holder, int position) {
                    holder.setTextView(R.id.tv_license_type, datas.get(position).getLicenseDesc());
                    if (datas.get(position).isStatus()) {
                        holder.setTextView(R.id.tv_license_status, getResources().getString(R.string.authenticated));
                        holder.setTextViewColor(R.id.tv_license_status, ContextCompat.getColor(MineLicenseListActivity.this, R.color.authentication_success_text));
                    } else {
                        holder.setTextView(R.id.tv_license_status, getResources().getString(R.string.unauthorized));
                    }
                }
            };
            rvLicenseList.setAdapter(recyclerViewAdapter);
            recyclerViewAdapter.setOnItemClickListener(new RecyclerViewAdapter.OnItemClickListener() {
                @Override
                public void onItemClick(int pos) {
                    ToastUtils.showShort("" + pos);
                    Intent intent = new Intent(MineLicenseListActivity.this, LicenseDetailActivity.class);
                    Bundle bundle = new Bundle();
                    bundle.putString("licenseDesc", datas.get(pos).getLicenseDesc());
                    bundle.putString("licenseType", datas.get(pos).getType());
                    intent.putExtras(bundle);
                    ActivityUtils.startActivity(intent);
                }
            });
            refreshLayout.finishRefresh(800);
        }
    }

    @Override
    public void requestFail(String msg) {
        rvLicenseList.setVisibility(View.GONE);
        rlEmptyPage.setVisibility(View.VISIBLE);
        refreshLayout.finishRefresh(500);
        if (mRefreshType == 1) {
            refreshLayout.finishLoadMore(800);
        }
    }
}
