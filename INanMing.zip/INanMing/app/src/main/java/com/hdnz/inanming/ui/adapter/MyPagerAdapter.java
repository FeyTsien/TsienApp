package com.hdnz.inanming.ui.adapter;

import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;
import android.support.v4.view.ViewPager;
import android.view.MotionEvent;

import java.util.List;

//ViewPage的适配器
public class MyPagerAdapter extends FragmentPagerAdapter{

    private List<Fragment> mList;
    private List<String> mListTitle;

    public MyPagerAdapter(FragmentManager fm, List<Fragment> list, List<String> listTitle) {
        super(fm);
        mList = list;
        mListTitle = listTitle;
    }

    @Override
    public Fragment getItem(int position) {
        return mList.get(position);
    }

    @Override
    public int getCount() {
        return mList.size();
    }

    @Override
    public CharSequence getPageTitle(int position) {
        return mListTitle.get(position);
    }

}