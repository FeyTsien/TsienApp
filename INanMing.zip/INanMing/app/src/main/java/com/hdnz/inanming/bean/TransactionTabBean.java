package com.hdnz.inanming.bean;

/**
 * Copyright (C), 2017-2018, 华电南自（贵州）科技有限公司
 * FileName:    TransactionTabBean.java
 * Author:      肖昕
 * Email:       xiaox@huadiannanzi.com
 * Date:        2018-11-15 11:37
 * Description:
 * Version:     V1.0.0
 * History:     历史信息
 */
public class TransactionTabBean {

}
