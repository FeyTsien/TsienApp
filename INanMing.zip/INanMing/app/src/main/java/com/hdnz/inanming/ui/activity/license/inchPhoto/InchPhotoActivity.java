package com.hdnz.inanming.ui.activity.license.inchPhoto;

import android.support.annotation.NonNull;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.blankj.utilcode.util.ToastUtils;
import com.bumptech.glide.Glide;
import com.hdnz.inanming.R;
import com.hdnz.inanming.bean.LicenseImgBean;
import com.hdnz.inanming.ui.activity.license.MineLicenseContract;
import com.hdnz.inanming.ui.activity.license.MineLicensePresenter;
import com.tsienlibrary.mvp.base.MVPBaseActivity;
import com.hdnz.inanming.utils.PopupWindowUtils;
import com.scwang.smartrefresh.layout.SmartRefreshLayout;
import com.scwang.smartrefresh.layout.api.RefreshLayout;
import com.scwang.smartrefresh.layout.listener.OnRefreshListener;

import butterknife.BindView;
import butterknife.OnClick;

/**
 * Copyright (C), 2017-2018, 华电南自（贵州）科技有限公司
 * FileName:    InchPhotoActivity.java
 * Author:      肖昕
 * Email:       xiaox@huadiannanzi.com
 * Date:        2018-11-15 10:09
 * Description: 一寸照/三寸照等activity
 * Version:     V1.0.0
 * History:     历史信息
 */
public class InchPhotoActivity extends MVPBaseActivity<MineLicenseContract.View, MineLicensePresenter>
        implements MineLicenseContract.View<LicenseImgBean> {

    @BindView(R.id.tv_title)
    TextView tvTitle;
    @BindView(R.id.tv_right_menu)
    TextView tvRightMenu;
    @BindView(R.id.toolbar)
    Toolbar mToolbar;
    @BindView(R.id.tv_single_photo_desc)
    TextView tvSinglePhotoDesc;
    @BindView(R.id.rl_single_photo_hide)
    RelativeLayout rlSinglePhotoHide;
    @BindView(R.id.iv_single_photo_show)
    ImageView ivSinglePhotoShow;
    @BindView(R.id.rl_single_photo_content)
    RelativeLayout rlSinglePhotoContent;
    @BindView(R.id.refreshLayout)
    SmartRefreshLayout refreshLayout;

    @Override
    protected int getLayoutId() {
        return R.layout.activity_inch_photo;
    }

    @Override
    protected void initData() {

    }
    @Override
    protected void initView() {
        setToolBar(mToolbar, tvTitle, getResources().getString(R.string.upload_inch_license_photo));
        tvRightMenu.setVisibility(View.VISIBLE);
        tvRightMenu.setText(R.string.save);
        tvSinglePhotoDesc.setText(getResources().getString(R.string.upload_inch_license_photo));

        refreshLayout.autoRefresh();
        refreshLayout.setOnRefreshListener(new OnRefreshListener() {
            @Override
            public void onRefresh(@NonNull RefreshLayout refreshLayout) {
                mPresenter.getLicenseByType("/license/img", "", "");
            }
        });
    }


    @Override
    public void requestSuccess(LicenseImgBean licenseImgBean) {
        if (licenseImgBean.getCode() == 200) {
            String imgUrl = licenseImgBean.getData().get(0);
            rlSinglePhotoHide.setVisibility(View.GONE);
            ivSinglePhotoShow.setVisibility(View.VISIBLE);
            Glide.with(this).load(imgUrl).into(ivSinglePhotoShow);
        }else {
            rlSinglePhotoHide.setVisibility(View.VISIBLE);
            ivSinglePhotoShow.setVisibility(View.GONE);
        }
        refreshLayout.finishRefresh(500);
    }

    @Override
    public void requestFail(String msg) {
        rlSinglePhotoHide.setVisibility(View.VISIBLE);
        ivSinglePhotoShow.setVisibility(View.GONE);
        refreshLayout.finishRefresh(500);
    }

    @OnClick({R.id.tv_right_menu, R.id.rl_single_photo_content})
    public void onViewClicked(View view) {
        switch (view.getId()) {
            case R.id.tv_right_menu:
                ToastUtils.showShort("保存", Toast.LENGTH_SHORT);
                break;
            case R.id.rl_single_photo_content:
                new PopupWindowUtils(this).openPopupWindow(view, "");
                break;
        }
    }
}
