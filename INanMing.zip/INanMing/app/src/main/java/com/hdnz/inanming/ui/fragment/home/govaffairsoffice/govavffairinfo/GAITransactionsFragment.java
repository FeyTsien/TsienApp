package com.hdnz.inanming.ui.fragment.home.govaffairsoffice.govavffairinfo;

import android.support.annotation.NonNull;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.TextView;

import com.blankj.utilcode.util.ToastUtils;
import com.google.gson.Gson;
import com.hdnz.inanming.R;
import com.hdnz.inanming.bean.HeadLineBean;
import com.hdnz.inanming.bean.RequestBean;
import com.hdnz.inanming.mvp.contract.MVPContract;
import com.hdnz.inanming.mvp.presenter.MVPPresenter;
import com.hdnz.inanming.mvp.view.MVPFragment;
import com.hdnz.inanming.ui.adapter.ListViewAdapter;
import com.hdnz.inanming.utils.UrlUtils;
import com.scwang.smartrefresh.layout.SmartRefreshLayout;
import com.scwang.smartrefresh.layout.api.RefreshLayout;
import com.scwang.smartrefresh.layout.listener.OnRefreshLoadMoreListener;
import com.tsienlibrary.bean.CommonBean;

import java.util.ArrayList;
import java.util.List;

import butterknife.BindView;

/**
 * date:2017/6/7
 */


public class GAITransactionsFragment extends MVPFragment<MVPContract.View, MVPPresenter> {

    //当前指定页
    private int pageIndex = 1;

    List<String> mThemesList;
    List<String> mThemeItemesList;
    private ListViewAdapter mListViewAdapter;

    @BindView(R.id.refresh_layout)
    SmartRefreshLayout mSmartRefreshLayout;
    @BindView(R.id.list_view)
    ListView mListView;

    @Override
    protected int getLayoutId() {
        return R.layout.fragment_content_listview;
    }

    @Override
    protected void initData() {
        mThemesList = new ArrayList<>();
        mThemeItemesList = new ArrayList<>();
        mThemesList.add("个人社会保障卡");
        mThemesList.add("个人社会保障卡");
        mThemesList.add("个人社会保障卡");
        mThemesList.add("个人社会保障卡");
        mThemesList.add("个人社会保障卡");
        mThemesList.add("个人社会保障卡");
        mThemesList.add("个人社会保障卡");
        mThemesList.add("个人社会保障卡");
        mThemesList.add("个人社会保障卡");
        mThemesList.add("个人社会保障卡");
        mThemesList.add("个人社会保障卡");
        mThemesList.add("个人社会保障卡");
        mThemesList.add("个人社会保障卡");

    }

    @Override
    protected void initView() {
        mListViewAdapter = new ListViewAdapter<String>(mThemesList, R.layout.item_gai_transaction) {
            @Override
            public void bindView(MyViewHolder holder, String title) {
                TextView textView = holder.getView(R.id.tv_title);
                textView.setText(title);
            }
        };
        mListView.setAdapter(mListViewAdapter);
        mListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                ToastUtils.showShort("listView一级菜单" + position + "");
            }
        });

        //下拉刷新
        mSmartRefreshLayout.setOnRefreshLoadMoreListener(new OnRefreshLoadMoreListener() {
            @Override
            public void onLoadMore(@NonNull RefreshLayout refreshLayout) {
                mSmartRefreshLayout.finishLoadMore();
                //上拉加载更多
                pageIndex++;
                request();
            }

            @Override
            public void onRefresh(@NonNull RefreshLayout refreshLayout) {
                //下拉刷新
                pageIndex = 1;
                request();
            }
        });

        request();
    }

//
//    @Override
//    protected boolean isLoadSir() {
//        return true;
//    }


    @Override
    protected void request() {
        RequestBean requestBean = new RequestBean();
        RequestBean.PageBean pageBean = new RequestBean.PageBean();
        pageBean.setPageIndex(pageIndex);
        pageBean.setPageSize(10);
        requestBean.setPage(pageBean);
        RequestBean.ParamsBean paramsBean = new RequestBean.ParamsBean();
        paramsBean.setType("3");
        requestBean.setParams(paramsBean);
        Gson gson = new Gson();
        String jsonData = gson.toJson(requestBean);
        mPresenter.request(UrlUtils.COLLECT_SHOPS, jsonData, HeadLineBean.class);
        super.request();
    }

    @Override
    public void requestSuccess(String requestUrl, CommonBean commonBean) {
//
//        //获取到指定list，发送给WokebenchFragment,进行刷新
//        HeadLineBean headLineBean = (HeadLineBean) commonBean.getData();
//        if (pageIndex <= 1) {
//            mSmartRefreshLayout.finishRefresh();
//            if (headLineBean.getRecords().size() == 0) {
//                //没有数据
//                mBaseLoadService.showCallback(NotDataCallback.class);
//                return;
//            }
//            mThemesList.clear();
//            mThemesList.addAll(headLineBean.getRecords());
//        } else {
//            if (pageIndex >= headLineBean.getPages()) {
//                //当前页和总页数相同
//                //完成加载并标记没有更多数据
//                mSmartRefreshLayout.finishLoadMoreWithNoMoreData();
//                pageIndex = headLineBean.getPages();
//            } else {
//                //完成加载
//                mSmartRefreshLayout.finishLoadMore();
//            }
//            mThemesList.addAll(headLineBean.getRecords());
//        }
//        mAdapter.notifyDataSetChanged();
//        mBaseLoadService.showSuccess();
    }

    @Override
    public void requestFail(String requestUrl, String msg) {

    }

    /**
     * fragment静态传值
     */
    public static GAITransactionsFragment newInstance() {
        GAITransactionsFragment fragment = new GAITransactionsFragment();
        return fragment;
    }

}
