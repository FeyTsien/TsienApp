package com.hdnz.inanming.ui.fragment.me.collect;

import android.annotation.SuppressLint;
import android.support.annotation.NonNull;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;

import com.google.gson.Gson;
import com.hdnz.inanming.R;
import com.hdnz.inanming.bean.HeadLineBean;
import com.hdnz.inanming.bean.RequestBean;
import com.hdnz.inanming.mvp.contract.MVPContract;
import com.hdnz.inanming.mvp.presenter.MVPPresenter;
import com.hdnz.inanming.mvp.view.MVPFragment;
import com.hdnz.inanming.ui.adapter.RecyclerViewAdapter;
import com.hdnz.inanming.utils.UrlUtils;
import com.scwang.smartrefresh.layout.SmartRefreshLayout;
import com.scwang.smartrefresh.layout.api.RefreshLayout;
import com.scwang.smartrefresh.layout.listener.OnRefreshLoadMoreListener;
import com.tsienlibrary.bean.CommonBean;
import com.tsienlibrary.loadsir.callback.NotDataCallback;
import com.tsienlibrary.ui.widget.MultiItemDivider;

import java.util.ArrayList;
import java.util.List;

import butterknife.BindView;

/**
 * date:2017/6/7
 */


@SuppressLint("ValidFragment")
public class CollectArticlesFragment extends MVPFragment<MVPContract.View, MVPPresenter> {

    //当前指定页
    private int pageIndex = 1;

    List<HeadLineBean.RecordsBean> mShopsList;
    private RecyclerViewAdapter mAdapter;

    @BindView(R.id.refresh_layout)
    SmartRefreshLayout mSmartRefreshLayout;
    @BindView(R.id.recycler_view)
    RecyclerView mRecyclerView;

    @Override
    protected int getLayoutId() {
        return R.layout.fragment_content;
    }

    @Override
    protected void initData() {
        mShopsList = new ArrayList<>();
    }

    @Override
    protected void initView() {

        LinearLayoutManager layoutManager = new LinearLayoutManager(getActivity());
        layoutManager.setOrientation(LinearLayoutManager.VERTICAL);
        mRecyclerView.setLayoutManager(layoutManager);
        //添加分割线
        MultiItemDivider itemDivider = new MultiItemDivider(getActivity(), MultiItemDivider.VERTICAL_LIST, R.drawable.divider_mileage);
        itemDivider.setDividerMode(MultiItemDivider.INSIDE);//最后一个item下没有分割线
        // itemDivider.setDividerMode(MultiItemDivider.END);//最后一个item下有分割线
//        mRecyclerView.addItemDecoration(itemDivider);

        mAdapter = new RecyclerViewAdapter<HeadLineBean.RecordsBean>(mShopsList, R.layout.item_shop) {
            @Override
            public void bindView(MyViewHolder holder, int position) {
//                holder.setTextView(R.id.text_view, mPendingTasksList.get(position));
            }
        };

        mRecyclerView.setAdapter(mAdapter);


        //下拉刷新
        mSmartRefreshLayout.setOnRefreshLoadMoreListener(new OnRefreshLoadMoreListener() {
            @Override
            public void onLoadMore(@NonNull RefreshLayout refreshLayout) {
                //上拉加载更多
                pageIndex++;
                request();
            }

            @Override
            public void onRefresh(@NonNull RefreshLayout refreshLayout) {
                //下拉刷新
                pageIndex = 1;
                request();
            }
        });

        request();
    }

    @Override
    protected boolean isLoadSir() {
        return true;
    }

    @Override
    protected void request() {
        RequestBean requestBean = new RequestBean();
        RequestBean.PageBean pageBean = new RequestBean.PageBean();
        pageBean.setPageIndex(pageIndex);
        pageBean.setPageSize(10);
        requestBean.setPage(pageBean);
        RequestBean.ParamsBean paramsBean = new RequestBean.ParamsBean();
        paramsBean.setType("3");
        requestBean.setParams(paramsBean);
        Gson gson = new Gson();
        String jsonData = gson.toJson(requestBean);
        mPresenter.request(UrlUtils.COLLECT_ARTICLES, jsonData, HeadLineBean.class);
        super.request();
    }

    @Override
    public void requestSuccess(String requestUrl, CommonBean commonBean) {

        //获取到指定list，发送给WokebenchFragment,进行刷新
        HeadLineBean headLineBean = (HeadLineBean) commonBean.getData();
        if (pageIndex <= 1) {
            mSmartRefreshLayout.finishRefresh();
            if (headLineBean.getRecords().size() == 0) {
                //没有数据
                mBaseLoadService.showCallback(NotDataCallback.class);
                return;
            }
            mShopsList.clear();
            mShopsList.addAll(headLineBean.getRecords());
        } else {
            if (pageIndex >= headLineBean.getPages()) {
                //当前页和总页数相同
                //完成加载并标记没有更多数据
                mSmartRefreshLayout.finishLoadMoreWithNoMoreData();
                pageIndex = headLineBean.getPages();
            } else {
                //完成加载
                mSmartRefreshLayout.finishLoadMore();
            }
            mShopsList.addAll(headLineBean.getRecords());
        }
        mAdapter.notifyDataSetChanged();
        mBaseLoadService.showSuccess();
    }

    @Override
    public void requestFail(String requestUrl, String msg) {

    }

    /**
     * fragment静态传值
     */
    public static CollectArticlesFragment newInstance() {
        CollectArticlesFragment fragment = new CollectArticlesFragment();
        return fragment;
    }

}
