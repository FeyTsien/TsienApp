package com.hdnz.inanming.ui.activity.login;

/**
 * <pre>
 *     author : Tsien
 *     e-mail : 974490643@qq.com
 *     time   : 2018/12/28
 *     desc   :
 * </pre>
 */
public class LoginCode {
    //=======   发送验证码 type（smsType和type一致） ===========
    public static final String TYPE_LOGIN = "1";
    public static final String TYPE_LOG_UP = "2";
    public static final String TYPE_FORGET_PASSWORD = "3";
    public static final String TYPE_CHANGE_PHONE_NUMBER = "4";

    //======    登录区别码 loginType =================
        public static final String LOGIN_TYPE_CODE = "1";
        public static final String LOGIN_TYPE_PWD = "0";
}
