package com.hdnz.inanming.ui.fragment.workbench;

import android.annotation.SuppressLint;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;

import com.hdnz.inanming.R;
import com.hdnz.inanming.mvp.contract.MVPContract;
import com.hdnz.inanming.mvp.presenter.MVPPresenter;
import com.hdnz.inanming.mvp.view.MVPFragment;
import com.hdnz.inanming.ui.adapter.RecyclerViewAdapter;
import com.scwang.smartrefresh.layout.SmartRefreshLayout;
import com.scwang.smartrefresh.layout.api.RefreshLayout;
import com.scwang.smartrefresh.layout.listener.OnRefreshListener;
import com.tsienlibrary.bean.CommonBean;
import com.tsienlibrary.ui.widget.MultiItemDivider;

import java.util.ArrayList;
import java.util.List;

import butterknife.BindView;

/**
 * date:2017/6/7
 */


@SuppressLint("ValidFragment")
public class TaskFragmentA extends MVPFragment<MVPContract.View, MVPPresenter> {

    List<String> mPendingTasksList;
    private RecyclerViewAdapter mAdapter;

    @BindView(R.id.refresh_layout)
    SmartRefreshLayout mSmartRefreshLayout;
    @BindView(R.id.recycler_view)
    RecyclerView mRecyclerView;


    @Override
    protected int getLayoutId() {
        return R.layout.fragment_content;
    }

    @Override
    protected void initData() {
        mPendingTasksList = new ArrayList<>();
        mPendingTasksList.add("考勤11111111");
        mPendingTasksList.add("汇报111111");
        mPendingTasksList.add("文件111111");
        mPendingTasksList.add("通讯录1111111");
        mPendingTasksList.add("数治社工11111");
        mPendingTasksList.add("社区人事");
        mPendingTasksList.add("社区政务11111111");

    }

    @Override
    protected void initView() {

        mAdapter = new RecyclerViewAdapter<String>(mPendingTasksList, R.layout.item_task) {
            @Override
            public void bindView(RecyclerViewAdapter.MyViewHolder holder, int position) {
//                holder.setTextView(R.id.text_view, mPendingTasksList.get(position));
            }
        };

        LinearLayoutManager layoutManager = new LinearLayoutManager(getActivity());
        layoutManager.setOrientation(LinearLayoutManager.VERTICAL);
        mRecyclerView.setLayoutManager(layoutManager);
        //添加分割线
        MultiItemDivider itemDivider = new MultiItemDivider(getActivity(), MultiItemDivider.VERTICAL_LIST, R.drawable.divider_mileage);
        itemDivider.setDividerMode(MultiItemDivider.INSIDE);//最后一个item下没有分割线
        // itemDivider.setDividerMode(MultiItemDivider.END);//最后一个item下有分割线
//        mRecyclerView.addItemDecoration(itemDivider);

        mRecyclerView.setAdapter(mAdapter);


        //下拉刷新
        mSmartRefreshLayout.setOnRefreshListener(new OnRefreshListener() {
            @Override
            public void onRefresh(RefreshLayout refreshlayout) {
                refreshlayout.finishRefresh(2000/*,false*/);//传入false表示刷新失败
            }
        });

    }


    /**
     * fragment静态传值
     */
    public static TaskFragmentA newInstance() {
        TaskFragmentA fragment = new TaskFragmentA();
        return fragment;
    }

    @Override
    public void requestSuccess(String requestUrl, CommonBean commonBean) {
        //获取到指定list，发送给WokebenchFragment,进行刷新
    }

    @Override
    public void requestFail(String requestUrl, String msg) {

    }
}
