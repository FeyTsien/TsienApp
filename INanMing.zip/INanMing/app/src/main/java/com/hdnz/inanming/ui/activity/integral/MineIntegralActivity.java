package com.hdnz.inanming.ui.activity.integral;

import android.graphics.Typeface;
import android.support.annotation.NonNull;
import android.support.design.widget.AppBarLayout;
import android.support.design.widget.TabLayout;
import android.support.v4.content.ContextCompat;
import android.support.v4.view.ViewPager;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.blankj.utilcode.util.LogUtils;
import com.hdnz.inanming.R;
import com.hdnz.inanming.bean.IntegralBean;
import com.hdnz.inanming.bean.TabBannerBean;
import com.hdnz.inanming.ui.adapter.RecyclerViewAdapter;
import com.scwang.smartrefresh.layout.SmartRefreshLayout;
import com.scwang.smartrefresh.layout.api.RefreshLayout;
import com.scwang.smartrefresh.layout.listener.OnLoadMoreListener;
import com.scwang.smartrefresh.layout.listener.OnRefreshListener;
import com.stx.xhb.xbanner.XBanner;
import com.stx.xhb.xbanner.transformers.Transformer;
import com.tsienlibrary.mvp.base.MVPBaseActivity;
import com.yanzhenjie.recyclerview.swipe.widget.DefaultItemDecoration;

import java.util.ArrayList;
import java.util.List;

import butterknife.BindView;
import butterknife.OnClick;

/**
 * Copyright (C), 2017-2018, 华电南自（贵州）科技有限公司
 * FileName:    MineIntegralActivity.java
 * Author:      肖昕
 * Email:       xiaox@huadiannanzi.com
 * Date:        2018-11-22 10:19
 * Description: 我的积分activity
 * Version:     V1.0.0
 * History:     历史信息
 */
public class MineIntegralActivity extends MVPBaseActivity<MineIntegralContract.View, MineIntegralPresenter>
        implements MineIntegralContract.View<TabBannerBean, IntegralBean> {
    @BindView(R.id.cb_banner)
    XBanner cbBanner;
    @BindView(R.id.rv_integral_list)
    RecyclerView rvIntegralList;
    @BindView(R.id.rl_empty_page)
    RelativeLayout rlEmptyPage;
    @BindView(R.id.refreshLayout)
    SmartRefreshLayout refreshLayout;
    @BindView(R.id.tab_refresh)
    SmartRefreshLayout tabRefresh;
    @BindView(R.id.app_bar)
    AppBarLayout appBar;
    @BindView(R.id.tv_right_menu)
    TextView tvRightMenu;
    @BindView(R.id.btn_refresh)
    Button btnRefresh;
    @BindView(R.id.rl_error_page)
    RelativeLayout rlErrorPage;
    @BindView(R.id.rl_tab_banner)
    RelativeLayout rlTabBanner;
    @BindView(R.id.tv_title)
    TextView tvTitle;
    @BindView(R.id.toolbar)
    Toolbar mToolbar;
    @BindView(R.id.tb_cont)
    TabLayout mTabLayout;
    /**
     * @field tab标题
     */
    private List<String> tabTitles;
    /**
     * @field 本地图片
     */
    private List<Integer> localImages = new ArrayList<Integer>();
    private boolean isFirst = true;
    /**
     * @field banner滑动的位置
     */
    private int mPosition = 0;
    /**
     * @field 是否滑动过
     */
    private boolean isScroll = true;
    /**
     * @field banner数据
     */
    private TabBannerBean.DataBean.BannerBean bannerData;
    /**
     * @field 刷新类型  0下拉，1上拉
     */
    private int mRefreshType;
    /**
     * @field 积分数据
     */
    private List<IntegralBean.DataBean> integralDataList;
    /**
     * @field 适配器
     */
    private RecyclerViewAdapter<IntegralBean.DataBean> adapter;
    private List<TabBannerBean.DataBean.BannerBean.Banner> bannerList;

    @Override
    protected int getLayoutId() {
        return R.layout.activity_mine_integral;
    }

    /**
     * 初始化数据
     */
    @Override
    protected void initData() {
        if (null != bannerList) {
            bannerList.clear();
        }
        if (null != tabTitles) {
            tabTitles.clear();
        }
        if (null != localImages) {
            localImages.clear();
        }
        tabRefresh.autoRefresh();
        tabRefresh.setOnRefreshListener(new OnRefreshListener() {
            @Override
            public void onRefresh(@NonNull RefreshLayout refreshLayout) {
                mPresenter.getTabsAndBanner("tab-banner", "");
            }
        });
    }

    /**
     * 初始化
     */
    @Override
    protected void initView() {
        //设置title
        setToolBar(mToolbar, tvTitle, getResources().getString(R.string.my_integral));
//        tvRightMenu.setVisibility(View.VISIBLE);
        tvRightMenu.setText("刷新");
        initBottomView();
    }

    /**
     * 初始化底部列表、刷新、空数据控件
     */
    private void initBottomView() {
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(this);
        linearLayoutManager.setOrientation(LinearLayoutManager.VERTICAL);
        rvIntegralList.setLayoutManager(linearLayoutManager);
        rvIntegralList.addItemDecoration(new DefaultItemDecoration(ContextCompat.getColor(this, R.color.me_divider), 1, 1));
    }

    /**
     * 初始化tab选项卡和banner控件
     */
    private void initTopView() {
        //1、先进行tabLayout监听
        mTabLayout.addOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
            @Override
            public void onTabSelected(TabLayout.Tab tab) {
                LogUtils.e("xiaoxin onTabSelected:" + tab.getText() + "   mPosition: " + mPosition);
                updateTabTextView(tab, true);
                if (!isFirst) {
                    //改变banner的位置
                    changeBannerItem();
                    //请求数据
                    if (!isScroll) {
                        requestIntegralData(tab.getText().toString(), 0);
                        isScroll = true;
                    }
                } else {
                    //第一次加载
                    requestIntegralData(tab.getText().toString(), 0);
                }
                isFirst = false;
            }

            @Override
            public void onTabUnselected(TabLayout.Tab tab) {
                updateTabTextView(tab, false);
            }

            @Override
            public void onTabReselected(TabLayout.Tab tab) {

            }
        });
        //创建tab选项
        for (int i = 0; i < tabTitles.size(); i++) {
            TabLayout.Tab tab = mTabLayout.newTab();
            View view = View.inflate(this, R.layout.tab_integral_title, null);
            TextView tabText = (TextView) view.findViewById(R.id.tab_item_text);
            tabText.setText(tabTitles.get(i));
            tab.setCustomView(view);
            tab.setText(tabTitles.get(i));
            if (i == 2) {
                mTabLayout.addTab(tab, i, true);
            } else {
                mTabLayout.addTab(tab, i, false);
            }
        }
        //banner图设置
        cbBanner.setPageTransformer(Transformer.Default);
        cbBanner.setData(R.layout.banner_integral_store, localImages, null);
        cbBanner.loadImage(new XBanner.XBannerAdapter() {
            @Override
            public void loadBanner(XBanner banner, Object model, View view, int position) {
                if (bannerData != null) {
                    ImageView bannerImg = (ImageView) view.findViewById(R.id.iv_banner_img);
                    TextView tvTitle = (TextView) view.findViewById(R.id.tv_title);
                    TextView tvNumber = (TextView) view.findViewById(R.id.tv_number);
//                GlideApp.with(mContext).load(localImages.get(position)).placeholder(R.drawable.test).override(800, 700).into(bannerImg);
                    bannerImg.setImageResource(localImages.get(position));
                    tvTitle.setText(bannerList.get(position).getTitle());
                    tvNumber.setText(bannerList.get(position).getNumber());
                }
            }
        });
        cbBanner.setOnPageChangeListener(new ViewPager.OnPageChangeListener() {
            @Override
            public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {

            }

            @Override
            public void onPageSelected(int position) {
                LogUtils.e("xiaoxin banner onPageSelected: " + position);
                mPosition = position;
                if (isScroll) {
                    TabLayout.Tab tab = mTabLayout.getTabAt(mTabLayout.getSelectedTabPosition());
                    requestIntegralData(tab.getText().toString(), position);
                }
            }

            @Override
            public void onPageScrollStateChanged(int state) {

            }
        });
        cbBanner.setOnItemClickListener(new XBanner.OnItemClickListener() {
            @Override
            public void onItemClick(XBanner banner, Object model, View view, int position) {
                LogUtils.e("xiaoxin banner onItemClick: " + position + "---model: " + model);
            }
        });
    }

    /**
     * 改变banner的位置，默认设置到第一个
     */
    private void changeBannerItem() {
        isScroll = false;
        int currentItem = cbBanner.getViewPager().getCurrentItem();
        for (int i = 0, j = localImages.size(); i < j; i++) {
            if (i == mPosition) {
                if (i == 0) {
                    cbBanner.getViewPager().setCurrentItem(currentItem, false);
                } else if (i == j - 1) {
                    cbBanner.getViewPager().setCurrentItem(currentItem + 1, false);
                } else if (i == 1) {
                    cbBanner.getViewPager().setCurrentItem(currentItem - 1, false);
                } else {
                    for (int k = 0; k < i; k++) {
                        currentItem = currentItem - 1;
                        cbBanner.getViewPager().setCurrentItem(currentItem, false);
                    }
                }
            }
        }
    }


    @Override
    public void requestSuccess(TabBannerBean tabBannerBean) {
        tabRefresh.finishRefresh(200);

        if (tabBannerBean != null && tabBannerBean.getData() != null) {
            rlTabBanner.setVisibility(View.VISIBLE);
            rlErrorPage.setVisibility(View.GONE);
            TabBannerBean.DataBean.TabBean tab = tabBannerBean.getData().getTab();
            bannerData = tabBannerBean.getData().getBanner();
            bannerList = bannerData.getBanner();
            tabTitles = tab.getTab();
            //添加本地图片
            localImages.add(R.drawable.bg_light_bule);
            localImages.add(R.drawable.bg_red);
            localImages.add(R.drawable.bg_yellow);
            initTopView();
        } else {

        }
    }

    @Override
    public void requestSuccessList(IntegralBean integralBean) {
        tabRefresh.setEnableRefresh(false);
        if (null != integralBean && null != integralBean.getData() && integralBean.getData().size() > 0) {
            rvIntegralList.setVisibility(View.VISIBLE);
            rlEmptyPage.setVisibility(View.GONE);
            if (mRefreshType == 0) {
                if (integralDataList != null) {
                    integralDataList.clear();
                }
                //下拉
                integralDataList = integralBean.getData();
                adapter = new RecyclerViewAdapter<IntegralBean.DataBean>(integralDataList, R.layout.item_integral) {
                    @Override
                    public void bindView(MyViewHolder holder, int position) {
                        holder.setTextView(R.id.tv_status_title, integralDataList.get(position).getTitle());
                        holder.setTextView(R.id.tv_prove_type, integralDataList.get(position).getProveType());
                        holder.setTextView(R.id.tv_add_score, "+ " + integralDataList.get(position).getAddScore());
                        holder.setTextView(R.id.tv_datetime, integralDataList.get(position).getDateTime());
                    }
                };
                refreshLayout.finishRefresh(500);
                rvIntegralList.setAdapter(adapter);
            } else {
                //上拉
                refreshLayout.finishLoadMore(800);
                adapter.refresh(integralBean.getData());
            }
        }
    }

    @Override
    public void requestFail(String msg, String url) {
        if (url.equals("tab-banner")) {
            tabRefresh.finishRefresh(300);
            rlErrorPage.setVisibility(View.VISIBLE);
            rlTabBanner.setVisibility(View.GONE);
            tabRefresh.setEnableRefresh(false);
        }else {
            if (rlEmptyPage.getVisibility() != View.VISIBLE) {
                rlEmptyPage.setVisibility(View.VISIBLE);
            }
            if (rvIntegralList.getVisibility() == View.VISIBLE) {
                rvIntegralList.setVisibility(View.GONE);
            }
        }

        if (mRefreshType == 1) {
            refreshLayout.finishLoadMore(300);
        }else {
            refreshLayout.finishRefresh(300);
        }
    }

    /**
     * 更新tab标题的状态
     *
     * @param tab
     * @param isSelect
     */
    private void updateTabTextView(TabLayout.Tab tab, boolean isSelect) {
        //选中加粗
        TextView tabSelect = (TextView) tab.getCustomView().findViewById(R.id.tab_item_text);
        if (isSelect) {
            tabSelect.setTypeface(Typeface.defaultFromStyle(Typeface.BOLD));
            tabSelect.setText(tab.getText());
            tabSelect.setTextColor(ContextCompat.getColor(this, R.color.me_save));

        } else {
            tabSelect.setTypeface(Typeface.defaultFromStyle(Typeface.NORMAL));
            tabSelect.setText(tab.getText());
            tabSelect.setTextColor(ContextCompat.getColor(this, R.color.orange));
        }
    }

    /**
     * 根据月份和滑动的位置请求数据
     *
     * @param month
     * @param pos
     */
    private void requestIntegralData(String month, int pos) {
        refreshLayout.autoRefresh();
        LogUtils.e("requestIntegralData: " + month + " : " + pos);
        //下拉刷新
        refreshLayout.setOnRefreshListener(new OnRefreshListener() {
            @Override
            public void onRefresh(@NonNull RefreshLayout refreshLayout) {
                mRefreshType = 0;
                mPresenter.getIntegralList("integralList", "", pos + "", 0, 10);
            }
        });
        //上拉加载
        refreshLayout.setOnLoadMoreListener(new OnLoadMoreListener() {
            @Override
            public void onLoadMore(@NonNull RefreshLayout refreshLayout) {
                mRefreshType = 1;
                mPresenter.getIntegralList("integralList", "", pos + "", 0, 10);
            }
        });
    }

    @OnClick({R.id.tv_right_menu, R.id.btn_refresh})
    public void onViewClicked(View view) {
        switch (view.getId()) {
            case R.id.tv_right_menu:
                tabRefresh.setEnableRefresh(true);
                tabRefresh.autoRefresh();
                break;
            case R.id.btn_refresh:
                tabRefresh.setEnableRefresh(true);
                tabRefresh.autoRefresh();
                break;
        }
    }
}
