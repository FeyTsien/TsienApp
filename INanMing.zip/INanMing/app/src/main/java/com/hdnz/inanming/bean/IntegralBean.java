package com.hdnz.inanming.bean;

import java.util.List;

/**
 * Copyright (C), 2017-2018, 华电南自（贵州）科技有限公司
 * FileName:    IntegralBean.java
 * Author:      肖昕
 * Email:       xiaox@huadiannanzi.com
 * Date:        2018-11-26 10:48
 * Description:
 * Version:     V1.0.0
 * History:     历史信息
 */
public class IntegralBean {

    /**
     * data : [{"title":"任务奖励","proveType":"结婚证","addScore":20,"dateTime":"2018-11-26 10:45:31"},{"title":"任务积分","proveType":"居住证","addScore":61,"dateTime":"2018-11-26 10:45:31"},{"title":"任务奖励","proveType":"结婚证","addScore":22,"dateTime":"2018-11-26 10:45:31"},{"title":"任务积分","proveType":"居住证","addScore":63,"dateTime":"2018-11-26 10:45:31"},{"title":"任务积分","proveType":"居住证","addScore":64,"dateTime":"2018-11-26 10:45:31"},{"title":"消费积分","proveType":"办理贵州省老年人优待证","addScore":45,"dateTime":"2018-11-26 10:45:31"},{"title":"消费积分","proveType":"办理贵州省老年人优待证","addScore":46,"dateTime":"2018-11-26 10:45:31"},{"title":"任务积分","proveType":"居住证","addScore":67,"dateTime":"2018-11-26 10:45:31"},{"title":"任务奖励","proveType":"结婚证","addScore":28,"dateTime":"2018-11-26 10:45:31"},{"title":"消费积分","proveType":"办理贵州省老年人优待证","addScore":49,"dateTime":"2018-11-26 10:45:31"}]
     * code : 200
     * message : success
     * status : true
     */

    private int code;
    private String message;
    private boolean status;
    private List<DataBean> data;

    public int getCode() {
        return code;
    }

    public void setCode(int code) {
        this.code = code;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public boolean isStatus() {
        return status;
    }

    public void setStatus(boolean status) {
        this.status = status;
    }

    public List<DataBean> getData() {
        return data;
    }

    public void setData(List<DataBean> data) {
        this.data = data;
    }

    public static class DataBean {
        /**
         * title : 任务奖励
         * proveType : 结婚证
         * addScore : 20
         * dateTime : 2018-11-26 10:45:31
         */

        private String title;
        private String proveType;
        private int addScore;
        private String dateTime;

        public String getTitle() {
            return title;
        }

        public void setTitle(String title) {
            this.title = title;
        }

        public String getProveType() {
            return proveType;
        }

        public void setProveType(String proveType) {
            this.proveType = proveType;
        }

        public int getAddScore() {
            return addScore;
        }

        public void setAddScore(int addScore) {
            this.addScore = addScore;
        }

        public String getDateTime() {
            return dateTime;
        }

        public void setDateTime(String dateTime) {
            this.dateTime = dateTime;
        }
    }
}
