package com.hdnz.inanming.ui.activity.reservation;

import com.google.gson.Gson;
import com.hdnz.inanming.mvp.model.HttpManager;
import com.hdnz.inanming.bean.BookBean;
import com.tsienlibrary.mvp.base.BasePresenterImpl;

import io.reactivex.Observer;
import io.reactivex.disposables.Disposable;

/**
 * Copyright (C), 2017-2018, 华电南自（贵州）科技有限公司
 * FileName:    MineBookPresenter.java
 * Author:      肖昕
 * Email:       xiaox@huadiannanzi.com
 * Date:        2018-11-26 14:14
 * Description: 我的预约页面，具体业务处理类
 * Version:     V1.0.0
 * History:     历史信息
 */
public class MineBookPresenter extends BasePresenterImpl<MineBookContract.View> implements MineBookContract.Presenter {

    @Override
    public void getBookList(String url, String json) {
        HttpManager.getHttpManager()
                .getMethod(url, new Observer<String>() {
                    @Override
                    public void onSubscribe(Disposable d) {

                    }

                    @Override
                    public void onNext(String json) {
                        Gson gson = new Gson();
                        BookBean bookBean = gson.fromJson(json, BookBean.class);
                        if (mView != null) {
                            mView.requestSuccess(bookBean);
                        }
                    }

                    @Override
                    public void onError(Throwable e) {
                        if (mView != null) {
                            mView.requestFail(e.getMessage());
                        }
                    }

                    @Override
                    public void onComplete() {

                    }
                });
    }

    @Override
    public void cancelBook(String url, String json) {

    }
}
