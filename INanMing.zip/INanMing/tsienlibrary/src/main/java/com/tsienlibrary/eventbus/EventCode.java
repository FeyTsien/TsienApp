package com.tsienlibrary.eventbus;

public final class EventCode {
    public static final int MAIN_A = 0x111101;//主界面-MainActivity
    public static final int MAIN_B = 0x111102;//主界面-MainActivity
    public static final int MAIN_HOME_A = 0x111111;//主界面-首页-HomeFragment
    public static final int MAIN_WORKBENCH_A = 0x111121;//主界面-工作台-WorkbenchFragment
    public static final int MAIN_MESSAGE_A = 0x111131;//主界面-消息-MessageFragment
    public static final int MAIN_ME_A = 0x111141;//主界面-我的-MeFragment

    public static final int CONTENT_A = 0x222201;//列表内容共用类-ContentFragment

//    public static final int A = 0x111111;
//    public static final int B = 0x222222;
//    public static final int C = 0x333333;
//    public static final int D = 0x444444;
    // other more
}