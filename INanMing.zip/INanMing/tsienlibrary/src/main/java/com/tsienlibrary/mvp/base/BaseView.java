package com.tsienlibrary.mvp.base;

import android.content.Context;

/**
 * MVPPlugin
 */

public interface BaseView {
     Context getContext();
}
